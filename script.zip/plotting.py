# plotting.py

"""
Plotting utilities
"""

from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib import cycler
import numpy as np
# local imports
import validate


DEFAULT_PLOT_STYLE = {
    # Figure/layout
    "figsize": (6, 4),
    "dpi": 300,
    "tight_layout": True,

    # Titles/labels/ticks
    "title_fontsize": 12,
    "label_fontsize": 10,
    "tick_labelsize": 9,

    # Grid
    "grid": True,
    "grid_which": "both",
    "grid_alpha": 0.3,

    # Line defaults (single-series)
    "line_color": "#1f77b4",
    "line_style": "-",
    "line_width": 1.2,

    # Secondary line defaults
    "line2_color": "#ff7f0e",
    "line2_style": "-",
    "line2_width": 1.2,

    # Legend
    "legend": True,
    "legend_fontsize": 10,

    # Background
    "facecolor": "white",
}


def merge_style(style_overrides=None):
    """
    Return a copy of DEFAULT_PLOT_STYLE with any non-None overrides applied.
    """
    style = DEFAULT_PLOT_STYLE.copy()
    if style_overrides:
        for k, v in style_overrides.items():
            if v is not None:
                style[k] = v
    return style


# Prepare axes (x, y) for a simple plot
def prepare_xy_axes(style=DEFAULT_PLOT_STYLE):
    """
    Prepare an x,y plot.
    Returns (fig, ax).
    """

    fig = plt.figure(figsize=style["figsize"], dpi=style["dpi"])
    ax = fig.add_subplot(111)
    ax.set_facecolor(style["facecolor"])
    
    # Plot line colors
    ax.set_prop_cycle(
        cycler(color=[style["line_color"]]) +
        cycler(linestyle=[style["line_style"]]) +
        cycler(linewidth=[style["line_width"]])
    )

    # Grid
    ax.grid(style["grid"], which=style["grid_which"], alpha=style["grid_alpha"])

    # Ticks
    ax.tick_params(labelsize=style["tick_labelsize"])

    return fig, ax


# Prepare axes (x, y1, y2) for a combined dual-y axis plot
def prepare_xyy_axes(style=DEFAULT_PLOT_STYLE):
    """
    Prepare an x,y1,y2 plot.
    Returns (fig, ax_left, ax_right).
    """

    fig = plt.figure(figsize=style["figsize"], dpi=style["dpi"])
    ax_left = fig.add_subplot(111)
    ax_right = ax_left.twinx()

    ax_left.set_facecolor(style["facecolor"])
    ax_right.set_facecolor(style["facecolor"])

    # Plot line colors
    ax_left.set_prop_cycle(
        cycler(color=[style["line_color"]]) +
        cycler(linestyle=[style["line_style"]]) +
        cycler(linewidth=[style["line_width"]])
    )
    ax_right.set_prop_cycle(
        cycler(color=[style["line2_color"]]) +
        cycler(linestyle=[style["line2_style"]]) +
        cycler(linewidth=[style["line2_width"]])
    )

    # Grid only on left axis for clarity
    if style.get("grid", True):
        ax_left.grid(True, which=style["grid_which"], alpha=style["grid_alpha"])

    # Ticks
    ax_left.tick_params(labelsize=style["tick_labelsize"])
    ax_right.tick_params(labelsize=style["tick_labelsize"])

    return fig, ax_left, ax_right


# Resolve save path
def resolve_savepath(savepath, default_filename):
    """
    If savepath is a directory, append default_filename.
    Ensure parent directory exists. Return Path or None.
    """
    if savepath is None:
        return None
    p = Path(savepath)
    if p.is_dir():
        p = p / default_filename
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


# Plot data
def plot_sample_abs_vs_time_raw(
    sample_abs_df,
    title="Sample absorbance vs time (raw)",
    time_unit="s",                   # 's' or 'min'
    show=False,
    savepath=None,                   # directory or full file path
    style_overrides=None,
    label="Sample",
):
    """
    Plot the raw sample absorbance vs time using DEFAULT_PLOT_STYLE
    (with optional style overrides).
    Expects DataFrame columns: ['time_s', 'abs'].
    """
    style = merge_style(style_overrides)
    fig, ax = prepare_xy_axes(style)

    # Time axis
    factor = 1.0
    x_label = "Time (s)"
    if str(time_unit).lower() in ("min", "mins", "minutes"):
        factor = 1.0 / 60.0
        x_label = "Time (min)"

    # Data
    if sample_abs_df is not None and len(sample_abs_df) > 0:
        x = np.asarray(sample_abs_df["time_s"]) * factor
        y = np.asarray(sample_abs_df["abs"])

        ax.plot(x, y, label=label)

        if style.get("legend", True):
            ax.legend(fontsize=style["legend_fontsize"])

    # Labels/titles
    ax.set_title(title, fontsize=style["title_fontsize"])
    ax.set_xlabel(x_label, fontsize=style["label_fontsize"])
    ax.set_ylabel("Absorbance (a.u.)", fontsize=style["label_fontsize"])

    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, "sample_absorbance_vs_time_raw.png")
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        plt.show()

    return fig, ax


def plot_baseline_abs_vs_time_raw(
    baseline_abs_df,
    title="Baseline absorbance vs time (raw)",
    time_unit="s",                   # 's' or 'min'
    show=False,
    savepath=None,                   # directory or full file path
    style_overrides=None,
    label="Baseline",
):
    """
    Plot the raw baseline absorbance vs time using DEFAULT_PLOT_STYLE
    (with optional style overrides).
    Expects DataFrame columns: ['time_s', 'abs'].
    """
    style = merge_style(style_overrides)
    fig, ax = prepare_xy_axes(style)

    # Time axis
    factor = 1.0
    x_label = "Time (s)"
    if str(time_unit).lower() in ("min", "mins", "minutes"):
        factor = 1.0 / 60.0
        x_label = "Time (min)"

    # Data
    if baseline_abs_df is not None and len(baseline_abs_df) > 0:
        x = np.asarray(baseline_abs_df["time_s"]) * factor
        y = np.asarray(baseline_abs_df["abs"])

        ax.plot(x, y, label=label)

        if style.get("legend", True):
            ax.legend(fontsize=style["legend_fontsize"])

    # Labels/titles
    ax.set_title(title, fontsize=style["title_fontsize"])
    ax.set_xlabel(x_label, fontsize=style["label_fontsize"])
    ax.set_ylabel("Absorbance (a.u.)", fontsize=style["label_fontsize"])

    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, "baseline_absorbance_vs_time_raw.png")
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        plt.show()

    return fig, ax


def plot_sample_temp_abs_vs_time(
    sample_aligned_df,
    title="Sample: Temperature & Absorbance vs Time",
    time_unit="s",                   # 's' or 'min'
    show=False,
    savepath=None,                   # directory or full file path
    style_overrides=None,
    temp_label="Temperature",
    abs_label="Absorbance",
):
    """
    Dual-axis plot (x,y1,y2) for the *sample* aligned data.
    Expects DataFrame columns: ['time_s','temp_K','abs'] (aligned).
    Left y-axis: Temperature (K). Right y-axis: Absorbance (a.u.).
    """
    validate.check_aligned_triplet(sample_aligned_df, "sample_aligned_df")

    style = merge_style(style_overrides)
    fig, ax_left, ax_right = prepare_xyy_axes(style)

    # Time axis
    factor = 1.0
    x_label = "Time (s)"
    if str(time_unit).lower() in ("min", "mins", "minutes"):
        factor = 1.0 / 60.0
        x_label = "Time (min)"

    t = np.asarray(sample_aligned_df["time_s"]) * factor
    T = np.asarray(sample_aligned_df["temp_K"])
    A = np.asarray(sample_aligned_df["abs"])

    # Left axis (temperature) – use secondary line defaults
    ax_left.plot(
        t, T,
        color=style.get("line2_color", "C1"),
        linestyle=style.get("line2_style", "--"),
        linewidth=style.get("line2_width", style.get("line_width", 1.2)),
        label=temp_label,
    )
    ax_left.set_ylabel("Temperature (K)", fontsize=style["label_fontsize"])

    # Right axis (absorbance) – primary line defaults
    ax_right.plot(
        t, A,
        color=style["line_color"],
        linestyle=style["line_style"],
        linewidth=style["line_width"],
        label=abs_label,
    )
    ax_right.set_ylabel("Absorbance (a.u.)", fontsize=style["label_fontsize"])

    # Title/labels
    ax_left.set_title(title, fontsize=style["title_fontsize"])
    ax_left.set_xlabel(x_label, fontsize=style["label_fontsize"])

    # Legend: combine handles from both axes (if enabled)
    if style.get("legend", True):
        h1, l1 = ax_left.get_legend_handles_labels()
        h2, l2 = ax_right.get_legend_handles_labels()
        ax_left.legend(h1 + h2, l1 + l2, fontsize=style["legend_fontsize"], loc="best")

    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, "sample_temp_abs_vs_time.png")
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        plt.show()

    return fig, (ax_left, ax_right)


def plot_baseline_temp_abs_vs_time(
    baseline_aligned_df,
    title="Baseline: Temperature & Absorbance vs Time",
    time_unit="s",                   # 's' or 'min'
    show=False,
    savepath=None,                   # directory or full file path
    style_overrides=None,
    temp_label="Temperature",
    abs_label="Absorbance",
):
    """
    Dual-axis plot (x,y1,y2) for the *baseline* aligned data.
    Expects DataFrame columns: ['time_s','temp_K','abs'] (aligned).
    Left y-axis: Temperature (K). Right y-axis: Absorbance (a.u.).
    """
    validate.check_aligned_triplet(baseline_aligned_df, "baseline_aligned_df")

    style = merge_style(style_overrides)
    fig, ax_left, ax_right = prepare_xyy_axes(style)

    # Time axis
    factor = 1.0
    x_label = "Time (s)"
    if str(time_unit).lower() in ("min", "mins", "minutes"):
        factor = 1.0 / 60.0
        x_label = "Time (min)"

    t = np.asarray(baseline_aligned_df["time_s"]) * factor
    T = np.asarray(baseline_aligned_df["temp_K"])
    A = np.asarray(baseline_aligned_df["abs"])

    # Left axis (temperature) – secondary defaults
    ax_left.plot(
        t, T,
        color=style.get("line2_color", "C1"),
        linestyle=style.get("line2_style", "--"),
        linewidth=style.get("line2_width", style.get("line_width", 1.2)),
        label=temp_label,
    )
    ax_left.set_ylabel("Temperature (K)", fontsize=style["label_fontsize"])

    # Right axis (absorbance) – primary defaults
    ax_right.plot(
        t, A,
        color=style["line_color"],
        linestyle=style["line_style"],
        linewidth=style["line_width"],
        label=abs_label,
    )
    ax_right.set_ylabel("Absorbance (a.u.)", fontsize=style["label_fontsize"])

    # Title/labels
    ax_left.set_title(title, fontsize=style["title_fontsize"])
    ax_left.set_xlabel(x_label, fontsize=style["label_fontsize"])

    # Legend
    if style.get("legend", True):
        h1, l1 = ax_left.get_legend_handles_labels()
        h2, l2 = ax_right.get_legend_handles_labels()
        ax_left.legend(h1 + h2, l1 + l2, fontsize=style["legend_fontsize"], loc="best")

    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, "baseline_temp_abs_vs_time.png")
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        plt.show()

    return fig, (ax_left, ax_right)


def plot_sample_raw_temp_abs_dual(
    sample_temp_df,
    sample_abs_df,
    title="Sample (raw): Temperature & Absorbance vs Time",
    time_unit="s",                   # 's' or 'min'
    show=False,
    savepath=None,                   # directory or full file path
    style_overrides=None,
    temp_label="Temperature",
    abs_label="Absorbance",
):
    """
    Dual-axis x–y1–y2 plot for RAW sample data (no alignment).
    Left y-axis: Temperature (K) from sample_temp_df['time_s','temp_K'].
    Right y-axis: Absorbance (a.u.) from sample_abs_df['time_s','abs'].
    Different time grids and lengths are handled naturally.
    """
    style = merge_style(style_overrides)
    fig, ax_left, ax_right = prepare_xyy_axes(style)

    # Time unit handling (independent for each series)
    factor = 1.0
    x_label = "Time (s)"
    if str(time_unit).lower() in ("min", "mins", "minutes"):
        factor = 1.0 / 60.0
        x_label = "Time (min)"

    # Plot temperature on left axis (use secondary line defaults for visual distinction)
    if sample_temp_df is not None and len(sample_temp_df) > 0:
        tT = np.asarray(sample_temp_df["time_s"]) * factor
        TT = np.asarray(sample_temp_df["temp_K"])
        ax_left.plot(
            tT, TT,
            color=style.get("line2_color", "C1"),
            linestyle=style.get("line2_style", "--"),
            linewidth=style.get("line2_width", style.get("line_width", 1.2)),
            label=temp_label,
        )
        ax_left.set_ylabel("Temperature (K)", fontsize=style["label_fontsize"])

    # Plot absorbance on right axis (primary line defaults)
    if sample_abs_df is not None and len(sample_abs_df) > 0:
        tA = np.asarray(sample_abs_df["time_s"]) * factor
        AA = np.asarray(sample_abs_df["abs"])
        ax_right.plot(
            tA, AA,
            color=style["line_color"],
            linestyle=style["line_style"],
            linewidth=style["line_width"],
            label=abs_label,
        )
        ax_right.set_ylabel("Absorbance (a.u.)", fontsize=style["label_fontsize"])

    # Title/labels and legend
    ax_left.set_title(title, fontsize=style["title_fontsize"])
    ax_left.set_xlabel(x_label, fontsize=style["label_fontsize"])
    if style.get("legend", True):
        h1, l1 = ax_left.get_legend_handles_labels()
        h2, l2 = ax_right.get_legend_handles_labels()
        if h1 or h2:
            ax_left.legend(h1 + h2, l1 + l2, fontsize=style["legend_fontsize"], loc="best")

    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, "sample_raw_temp_abs_dual.png")
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        plt.show()

    return fig, (ax_left, ax_right)


def plot_baseline_raw_temp_abs_dual(
    baseline_temp_df,
    baseline_abs_df,
    title="Baseline (raw): Temperature & Absorbance vs Time",
    time_unit="s",                   # 's' or 'min'
    show=False,
    savepath=None,                   # directory or full file path
    style_overrides=None,
    temp_label="Temperature",
    abs_label="Absorbance",
):
    """
    Dual-axis x–y1–y2 plot for RAW baseline data (no alignment).
    Left y-axis: Temperature (K) from baseline_temp_df['time_s','temp_K'].
    Right y-axis: Absorbance (a.u.) from baseline_abs_df['time_s','abs'].
    Different time grids and lengths are handled naturally.
    """
    style = merge_style(style_overrides)
    fig, ax_left, ax_right = prepare_xyy_axes(style)

    # Time unit handling
    factor = 1.0
    x_label = "Time (s)"
    if str(time_unit).lower() in ("min", "mins", "minutes"):
        factor = 1.0 / 60.0
        x_label = "Time (min)"

    # Temperature (left axis) — use secondary line defaults for distinction
    if baseline_temp_df is not None and len(baseline_temp_df) > 0:
        tT = np.asarray(baseline_temp_df["time_s"]) * factor
        TT = np.asarray(baseline_temp_df["temp_K"])
        ax_left.plot(
            tT, TT,
            color=style.get("line2_color", "C1"),
            linestyle=style.get("line2_style", "--"),
            linewidth=style.get("line2_width", style.get("line_width", 1.2)),
            label=temp_label,
        )
        ax_left.set_ylabel("Temperature (K)", fontsize=style["label_fontsize"])

    # Absorbance (right axis) — primary line defaults
    if baseline_abs_df is not None and len(baseline_abs_df) > 0:
        tA = np.asarray(baseline_abs_df["time_s"]) * factor
        AA = np.asarray(baseline_abs_df["abs"])
        ax_right.plot(
            tA, AA,
            color=style["line_color"],
            linestyle=style["line_style"],
            linewidth=style["line_width"],
            label=abs_label,
        )
        ax_right.set_ylabel("Absorbance (a.u.)", fontsize=style["label_fontsize"])

    # Title / labels / legend
    ax_left.set_title(title, fontsize=style["title_fontsize"])
    ax_left.set_xlabel(x_label, fontsize=style["label_fontsize"])
    if style.get("legend", True):
        h1, l1 = ax_left.get_legend_handles_labels()
        h2, l2 = ax_right.get_legend_handles_labels()
        if h1 or h2:
            ax_left.legend(h1 + h2, l1 + l2, fontsize=style["legend_fontsize"], loc="best")

    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, "baseline_raw_temp_abs_dual.png")
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        plt.show()

    return fig, (ax_left, ax_right)


def plot_baseline_abs_vs_temp_with_fit(
    baseline_aligned_df,
    model,
    title="Baseline: Absorbance vs Temperature (fit overlay, up-ramp only)",
    show=False,
    savepath=None,                   # directory or full file path
    style_overrides=None,
    data_label="Baseline (up-ramp)",
    fit_label="Polynomial fit",
    n_points=400,              # points for smooth fit curve
):
    """
    Plot baseline absorbance vs temperature with the fitted polynomial overlay.
    Plot uses DEFAULT_PLOT_STYLE (with optional style overrides).
    Only data up to the maximum temperature is shown (down-ramp excluded).
    Expects DataFrame columns: ['time_s', 'temp_K', 'abs'].
    """
    style = merge_style(style_overrides)
    fig, ax = prepare_xy_axes(style)

    # Data
    if baseline_aligned_df is not None and len(baseline_aligned_df) > 0:
        x = np.asarray(baseline_aligned_df["temp_K"], dtype=float)
        y = np.asarray(baseline_aligned_df["abs"], dtype=float)

        # Cut off at Tmax
        i_max = int(np.argmax(x))
        x = x[: i_max + 1]
        y = y[: i_max + 1]

        ax.plot(x, y, label=data_label)

        # Fit curve over the model's fit domain
        coeffs = np.asarray(model["coeffs_descending"], dtype=float)
        Tmin = float(model["Tmin_fit"])
        Tmax = float(model["Tmax_fit"])
        T_curve = np.linspace(Tmin, Tmax, int(max(10, n_points)))
        A_curve = np.polyval(coeffs, T_curve)

        ax.plot(
            T_curve, A_curve,
            label=fit_label,
            color='C1' # manual correct to color
        )

        if style.get("legend", True):
            ax.legend(fontsize=style["legend_fontsize"])

    # Labels/titles
    ax.set_title(title, fontsize=style["title_fontsize"])
    ax.set_xlabel("Temperature (K)", fontsize=style["label_fontsize"])
    ax.set_ylabel("Absorbance (a.u.)", fontsize=style["label_fontsize"])

    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, "baseline_abs_vs_temp_fit.png")
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        plt.show()

    return fig, ax


def plot_baseline_residuals(
    fit_df,
    title="Baseline fit residuals",
    show=False,
    savepath=None,
    style_overrides=None,
    x_label="Temperature (K)",
    y_label="Residual (A_obs - A_fit)",
):
    """
    Plot residuals (A_obs - A_fit) vs temperature for the baseline polynomial fit.

    Parameters
    ----------
    fit_df : DataFrame with columns ['temp_K','residual']
             (from baseline.fit_baseline_poly)
    title : str, plot title
    show : bool, whether to display plot interactively
    savepath : str or Path, directory or file path for saving the figure
    style_overrides : dict, optional style overrides
    x_label : str, x-axis label
    y_label : str, y-axis label

    Returns
    -------
    (fig, ax)
    """
    style = merge_style(style_overrides)
    fig, ax = prepare_xy_axes(style)

    T = np.asarray(fit_df["temp_K"], dtype=float)
    R = np.asarray(fit_df["residual"], dtype=float)

    # Residuals as scatter with faint horizontal line at zero
    ax.plot(
        T, R,
        label="Residuals",
    )
    ax.axhline(0, color="gray", linestyle="-", linewidth=2)

    ax.set_xlabel(x_label, fontsize=style["label_fontsize"])
    ax.set_ylabel(y_label, fontsize=style["label_fontsize"])
    ax.set_title(title, fontsize=style["title_fontsize"])

    if style.get("legend", True):
        ax.legend(fontsize=style["legend_fontsize"], loc="best")

    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, "baseline_residuals.png")
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        plt.show()

    return fig, ax


def _section_abs_temp_time_plot(
    df_section,
    title,
    save_basename,
    show=False,
    savepath=None,
    style_overrides=None,
    abs_col_pref=("abs_corr", "abs"),   # prefer corrected absorbance if present
):
    """
    Generic plot for a section: x=time_s, y1=absorbance, y2=temp_K (twin axes).
    Returns (fig, ax_left, ax_right) or (None, None, None) if df is empty.
    """
    import numpy as np
    if df_section is None or len(df_section) == 0:
        print(f"[plot] Skipping '{title}' — empty section.")
        return None, None, None

    style = merge_style(style_overrides)
    fig, ax = prepare_xy_axes(style)
    ax2 = ax.twinx()

    # choose absorbance column
    abs_col = None
    for c in abs_col_pref:
        if c in df_section.columns:
            abs_col = c
            break
    if abs_col is None:
        raise ValueError(f"Section plot '{title}': no absorbance column found in {abs_col_pref}")

    # data
    t = df_section["time_s"].to_numpy(float)
    A = df_section[abs_col].to_numpy(float)
    T = df_section["temp_K"].to_numpy(float)

    # lines: distinct colours/styles so they don't collide with global cycle
    abs_color = style.get("line_color", "C0")
    abs_ls    = style.get("line_style", "-")
    abs_lw    = style.get("line_width", 1.5)

    temp_color = style.get("line2_color", "C1")
    temp_ls    = style.get("line2_style", "--")
    temp_lw    = style.get("line2_width", style.get("line_width", 1.5))

    # plot
    ax.plot(t, A, color=abs_color, linestyle=abs_ls, linewidth=abs_lw, label="Absorbance")
    ax2.plot(t, T, color=temp_color, linestyle=temp_ls, linewidth=temp_lw, label="Temperature")

    # labels / title
    ax.set_xlabel("Time (s)", fontsize=style["label_fontsize"])
    ax.set_ylabel("Absorbance (a.u.)", fontsize=style["label_fontsize"])
    ax2.set_ylabel("Temperature (K)", fontsize=style["label_fontsize"])
    ax.set_title(title, fontsize=style["title_fontsize"])

    # grids + ticks
    if style.get("grid", True):
        ax.grid(True, which=style.get("grid_which", "major"), alpha=style.get("grid_alpha", 0.3))
    ax.tick_params(labelsize=style["tick_labelsize"])
    ax2.tick_params(labelsize=style["tick_labelsize"])

    # legends: combine handles from both axes
    if style.get("legend", True):
        h1, l1 = ax.get_legend_handles_labels()
        h2, l2 = ax2.get_legend_handles_labels()
        ax.legend(h1 + h2, l1 + l2, loc="best", fontsize=style["legend_fontsize"])

    if style.get("tight_layout", True):
        fig.tight_layout()

    # save
    outpath = resolve_savepath(savepath, f"{save_basename}.png")
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        import matplotlib.pyplot as plt
        plt.show()

    return fig, ax, ax2


def plot_section_up_time_abs_temp(df_up, show=False, savepath=None, style_overrides=None):
    return _section_abs_temp_time_plot(
        df_section=df_up,
        title="Sample (Up-ramp): Absorbance & Temperature vs Time",
        save_basename="section_up_abs_temp_vs_time",
        show=show,
        savepath=savepath,
        style_overrides=style_overrides,
    )


def plot_section_hold_time_abs_temp(df_hold, show=False, savepath=None, style_overrides=None):
    return _section_abs_temp_time_plot(
        df_section=df_hold,
        title="Sample (Hold): Absorbance & Temperature vs Time",
        save_basename="section_hold_abs_temp_vs_time",
        show=show,
        savepath=savepath,
        style_overrides=style_overrides,
    )


def plot_section_down_time_abs_temp(df_down, show=False, savepath=None, style_overrides=None):
    return _section_abs_temp_time_plot(
        df_section=df_down,
        title="Sample (Down-ramp): Absorbance & Temperature vs Time",
        save_basename="section_down_abs_temp_vs_time",
        show=show,
        savepath=savepath,
        style_overrides=style_overrides,
    )


def plot_calibration_abs_vs_temp_with_fit(
    down_df,
    model,
    title="Calibration (Down-ramp): Absorbance vs Temperature (fit overlay)",
    show=False,
    savepath=None,
    style_overrides=None,
    data_label="Down-ramp data",
    fit_label="Calibration fit",
    n_points=400,
):
    """
    Plot calibration down-ramp Abs vs T with polynomial fit overlay.
    Data as a line; fit as a line with a distinct style/colour.
    """
    style = merge_style(style_overrides)
    fig, ax = prepare_xy_axes(style)

    # Data
    if down_df is not None and len(down_df) > 0:
        x = np.asarray(down_df["temp_K"], dtype=float)
        y = np.asarray(down_df["abs_corr"], dtype=float)

        ax.plot(x, y, label=data_label)

        # Fit curve over the model's fit domain
        coeffs = np.asarray(model["coeffs_descending"], dtype=float)
        Tmin = float(model["Tmin_fit"])
        Tmax = float(model["Tmax_fit"])
        T_curve = np.linspace(Tmin, Tmax, int(max(10, n_points)))
        A_curve = np.polyval(coeffs, T_curve)

        ax.plot(
            T_curve, A_curve,
            label=fit_label,
            color='C1' # manual correct to color
        )

        if style.get("legend", True):
            ax.legend(fontsize=style["legend_fontsize"], loc="best")

    # Labels/titles
    ax.set_title(title, fontsize=style["title_fontsize"])
    ax.set_xlabel("Temperature (K)", fontsize=style["label_fontsize"])
    ax.set_ylabel("Absorbance (a.u.)", fontsize=style["label_fontsize"])

    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, "calibration_abs_vs_temp_fit.png")
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        plt.show()

    return fig, ax


def plot_calibration_residuals(
    fit_df,
    title="Calibration fit residuals",
    show=False,
    savepath=None,
    style_overrides=None,
    x_label="Temperature (K)",
    y_label="Residual (A_obs - A_fit)",
):
    """
    Residuals of the calibration polynomial fit vs temperature.
    """
    style = merge_style(style_overrides)
    fig, ax = prepare_xy_axes(style)

    T = np.asarray(fit_df["temp_K"], dtype=float)
    R = np.asarray(fit_df["residual"], dtype=float)

    # Residuals as scatter with faint horizontal line at zero
    ax.plot(
        T, R,
        label="Residuals",
    )

    ax.axhline(0, color="gray", linestyle="-", linewidth=2)

    ax.set_xlabel(x_label, fontsize=style["label_fontsize"])
    ax.set_ylabel(y_label, fontsize=style["label_fontsize"])
    ax.set_title(title, fontsize=style["title_fontsize"])

    if style.get("legend", True):
        ax.legend(fontsize=style["legend_fontsize"], loc="best")

    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, "calibration_residuals.png")
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        import matplotlib.pyplot as plt
        plt.show()

    return fig, ax


def plot_kinetics_abs_vs_time(
    fit_df,
    title="Kinetics fit: Absorbance vs Time",
    show=False,
    savepath=None,
    style_overrides=None,
    data_label="Data",
    fit_label="Fit",
    sort_by_time=True,
    filename="kinetics_abs_vs_time_fit.png",
):
    """
    Plot baseline-corrected experimental absorbance vs time with the fitted curve.

    Parameters
    ----------
    fit_df : pd.DataFrame
        Must contain columns: ['time_s', 'abs_corr', 'abs_fit'].
    title : str
        Plot title.
    show : bool
        If True, display the plot interactively.
    savepath : str or pathlib.Path or None
        Directory or full file path to save; if a directory, `filename` is used.
        If None, the figure is not saved.
    style_overrides : dict or None
        Optional style overrides merged into DEFAULT_PLOT_STYLE.
    data_label : str
        Legend label for experimental data.
    fit_label : str
        Legend label for fitted curve.
    sort_by_time : bool
        If True (default), sort by time so the fitted line draws cleanly.
    filename : str
        Default filename when savepath is a directory.

    Returns
    -------
    (fig, ax)
    """
    # Validate columns
    validate.require_columns(fit_df, ["time_s", "abs_corr", "abs_fit"], "plot_kinetics_abs_vs_time")

    style = merge_style(style_overrides)
    fig, ax = prepare_xy_axes(style)

    # Extract arrays
    t = np.asarray(fit_df["time_s"], dtype=float)
    a_obs = np.asarray(fit_df["abs_corr"], dtype=float)
    a_fit = np.asarray(fit_df["abs_fit"], dtype=float)

    if sort_by_time:
        idx = np.argsort(t)
        t_plot = t[idx]
        a_obs_plot = a_obs[idx]
        a_fit_plot = a_fit[idx]
    else:
        t_plot = t
        a_obs_plot = a_obs
        a_fit_plot = a_fit

    # Experimental data (scatter)
    ax.plot(
        t_plot, a_obs_plot,
        linestyle="",
        marker=style.get("data_marker", "o"),
        markersize=style.get("data_markersize", 3.0),
        alpha=style.get("data_alpha", 0.7),
        label=data_label,
        color=style.get("line2_color", "C1"),
    )

    # Fitted curve (line)
    ax.plot(
        t_plot, a_fit_plot,
        linestyle=style.get("line_style", "-"),
        linewidth=style.get("line_width", 1.5),
        color=style.get("line_color", "C0"),
        label=fit_label,
    )

    ax.set_xlabel("Time (s)", fontsize=style["label_fontsize"])
    ax.set_ylabel("Absorbance (a.u.)", fontsize=style["label_fontsize"])
    ax.set_title(title, fontsize=style["title_fontsize"])

    if style.get("legend", True):
        ax.legend(fontsize=style.get("legend_fontsize", 10), loc="best")

    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, filename)
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        import matplotlib.pyplot as plt
        plt.show()

    return fig, ax


def plot_eyring_points(
    points_df,
    title="Local Eyring plot",
    show=False,
    savepath=None,
    style_overrides=None,
    filename="eyring_points.png",
    add_trend=True,
):
    """
    Plot ln(k/T) vs 1/T using points produced by eyring.eyring_points_from_segments(...).

    Parameters
    ----------
    points_df : DataFrame with columns ['inv_T','ln_k_over_T'] (others optional).
    title : str
    show : bool
    savepath : str or Path or None
    style_overrides : dict or None
    filename : str
    add_trend : bool   # overlay simple linear trend for visual guidance

    Returns
    -------
    (fig, ax)
    """
    import numpy as np

    validate.require_columns(points_df, ["inv_T", "ln_k_over_T"], "plot_eyring_points")

    style = merge_style(style_overrides)
    fig, ax = prepare_xy_axes(style)

    x = points_df["inv_T"].to_numpy(dtype=float)
    y = points_df["ln_k_over_T"].to_numpy(dtype=float)

    ax.plot(
        x, y,
        linestyle="",
        marker=style.get("data_marker", "o"),
        markersize=style.get("data_markersize", 3.0),
        alpha=style.get("data_alpha", 0.8),
        label="Local points",
        color=style.get("line2_color", "C1"),
    )

    if add_trend and x.size >= 2 and np.isfinite(x).all() and np.isfinite(y).all():
        b1, b0 = np.polyfit(x, y, deg=1)
        xs = np.linspace(x.min(), x.max(), 200)
        ys = b1 * xs + b0
        ax.plot(
            xs, ys,
            linestyle=style.get("line_style", "-"),
            linewidth=style.get("line_width", 1.5),
            color=style.get("line_color", "C0"),
            label="Linear trend",
        )

    ax.set_xlabel("1 / T (K$^{-1}$)", fontsize=style["label_fontsize"])
    ax.set_ylabel("ln(k / T)", fontsize=style["label_fontsize"])
    ax.set_title(title, fontsize=style["title_fontsize"])
    if style.get("legend", True):
        ax.legend(fontsize=style.get("legend_fontsize", 10), loc="best")
    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, filename)
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        import matplotlib.pyplot as plt
        plt.show()

    return fig, ax

def plot_eyring_points(
    points_df,
    title="Local Eyring plot",
    show=False,
    savepath=None,
    style_overrides=None,
    filename="eyring_points.png",
    add_trend=True,
):
    """
    Plot ln(k/T) vs 1/T using points produced by eyring.eyring_points_from_segments(...).

    Parameters
    ----------
    points_df : DataFrame with columns ['inv_T','ln_k_over_T'] (others optional).
    title : str
    show : bool
    savepath : str or Path or None
    style_overrides : dict or None
    filename : str
    add_trend : bool   # overlay simple linear trend for visual guidance

    Returns
    -------
    (fig, ax)
    """
    import numpy as np

    validate.require_columns(points_df, ["inv_T", "ln_k_over_T"], "plot_eyring_points")

    style = merge_style(style_overrides)
    fig, ax = prepare_xy_axes(style)

    x = points_df["inv_T"].to_numpy(dtype=float)
    y = points_df["ln_k_over_T"].to_numpy(dtype=float)

    ax.plot(
        x, y,
        linestyle="",
        marker=style.get("data_marker", "o"),
        markersize=style.get("data_markersize", 3.0),
        alpha=style.get("data_alpha", 0.01),
        label="Local points",
        color=style.get("line2_color", "C1"),
    )

    if add_trend and x.size >= 2 and np.isfinite(x).all() and np.isfinite(y).all():
        b1, b0 = np.polyfit(x, y, deg=1)
        xs = np.linspace(x.min(), x.max(), 200)
        ys = b1 * xs + b0
        ax.plot(
            xs, ys,
            linestyle=style.get("line_style", "-"),
            linewidth=style.get("line_width", 1.5),
            color=style.get("line_color", "C0"),
            label="Linear trend",
        )

    ax.set_xlabel("1 / T (K$^{-1}$)", fontsize=style["label_fontsize"])
    ax.set_ylabel("ln(k / T)", fontsize=style["label_fontsize"])
    ax.set_title(title, fontsize=style["title_fontsize"])
    if style.get("legend", True):
        ax.legend(fontsize=style.get("legend_fontsize", 10), loc="best")
    if style.get("tight_layout", True):
        fig.tight_layout()

    outpath = resolve_savepath(savepath, filename)
    if outpath is not None:
        fig.savefig(outpath, dpi=style["dpi"])
        print(f"Saved plot: {outpath}")

    if show:
        import matplotlib.pyplot as plt
        plt.show()

    return fig, ax