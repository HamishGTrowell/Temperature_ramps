# align.py
"""
Absorbance and temperature data collected on different instruments.
align.py is used to sync these to a common time axis.
"""

import numpy as np
import pandas as pd
# local imports
import validate


def _median_dt(df):
    """Compute the median sampling interval from a time series.

        Args:
            df (DataFrame): ['time_s','temp_K'] or ['time_s','abs']

        Returns:
            (float): Median time step in seconds.
    """

    t = df["time_s"].to_numpy()
    return float(np.median(np.diff(t)))


def _choose_master_axis(temp_df, abs_df):
    """
    Decide which time grid to use (higher density preferred = smaller sampling interval).
    
        Args:
            temp_df (DataFrame): ['time_s','temp_K']
            abs_df (DataFrame): ['time_s','abs']
        
        Returns:
            string: 'abs' or 'temp'.
    """

    m_dt_temp = _median_dt(temp_df)
    m_dt_abs = _median_dt(abs_df)

    if m_dt_abs <= m_dt_temp:
        return "abs", m_dt_temp, m_dt_abs
    if m_dt_temp <= m_dt_abs:
        return "temp", m_dt_temp, m_dt_abs


def _build_linear_interpolator(x, y):
    """
    Build a linear interpolator f(q) over (x,y)
    e.g. x = time (s), y = temperature (K)
    Out-of-range q return clamped boundary y values
    Clamped values are dropped after trimming to overlap

        Args:
            x (1D array[float])
            y (1D array[float])
    
        Returns:
            f(q) (1D array[float]): interpolated values
            meta (dict): {xmin, xmax}
    """

    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)

    # Check input x and y are 1 dimensional data of same (and sufficient) size
    if x.ndim != 1 or y.ndim != 1 or x.size != y.size or x.size < 2:
        raise ValueError("Interpolator requires 1D x,y arrays of same length >= 2.")

    xmin = float(x[0])
    xmax = float(x[-1])

    def f(q):
        q = np.asarray(q, dtype=float)
        return np.interp(q, x, y, left=y[0], right=y[-1])

    meta = {"xmin": xmin, "xmax": xmax}
    return f, meta


def time_align_T_and_A(temp_df, abs_df, label_prefix, rebase_time=True, trim_to_overlap=True):
    """
    Align temperature and absorbance data onto a common time grid chosen by higher density.
    
        Args:
            temp_df (DataFrame): ['time_s','temp_K']
            abs_df (DataFrame): ['time_s','abs']
            label_prefix (str): 'baseline' or 'sample'
            rebase_time (bool): if True subtract t0 so time starts at t=0, default True
            trim_to_overlap (bool): if True drop non-overlapping data (based on time overlap), default True
    
        Returns:
            aligned_df (DataFrame): ['time_s','temp_K','abs'] on the chosen master time axis
            diag (dict): diagnostics
    """

    # Validate input DataFrames
    validate.check_time_temp(temp_df, f"{label_prefix}/temperature")
    validate.check_time_abs(abs_df,  f"{label_prefix}/absorbance")

    # Decide on which time grid to use
    master, m_dt_temp, m_dt_abs = _choose_master_axis(temp_df, abs_df)

    # Build interpolators on their native axes
    T_of_t, meta_T = _build_linear_interpolator(temp_df["time_s"].to_numpy(),
                                                temp_df["temp_K"].to_numpy())
    A_of_t, meta_A = _build_linear_interpolator(abs_df["time_s"].to_numpy(),
                                                abs_df["abs"].to_numpy())

    # Raw master grid (before trimming)
    if master == "abs":
        t_master_raw = abs_df["time_s"].to_numpy()
        other_min = meta_T["xmin"]
        other_max = meta_T["xmax"]
        # Overhangs measured on raw times (for diagnostics)
        overhang_low  = float(max(0.0, other_min - np.min(t_master_raw)))
        overhang_high = float(max(0.0, np.max(t_master_raw) - other_max))
        # Determine trimming mask against temperature domain
        if trim_to_overlap:
            keep = (t_master_raw >= other_min) & (t_master_raw <= other_max)
        else:
            keep = np.ones_like(t_master_raw, dtype=bool)
    elif master == "temp":
        t_master_raw = temp_df["time_s"].to_numpy()
        other_min = meta_A["xmin"]
        other_max = meta_A["xmax"]
        # Overhangs measured on raw times (for diagnostics)
        overhang_low  = float(max(0.0, other_min - np.min(t_master_raw)))
        overhang_high = float(max(0.0, np.max(t_master_raw) - other_max))
        # Determine trimming mask against absorbance domain
        if trim_to_overlap:
            keep = (t_master_raw >= other_min) & (t_master_raw <= other_max)
        else:
            keep = np.ones_like(t_master_raw, dtype=bool)

    # For diagnostics
    n_points_raw = int(t_master_raw.size) # number of datapoints kept before trimming
    n_trim_low  = int(np.sum(t_master_raw < other_min))
    n_trim_high = int(np.sum(t_master_raw > other_max))
    n_kept = int(np.sum(keep)) # number of datapoints kept after trimming

    # Apply trimming
    t_master_kept = t_master_raw[keep]

    # Interpolate on the kept grid
    if master == "abs":
        temp_at_master = T_of_t(t_master_kept)
        abs_at_master  = abs_df["abs"].to_numpy()[keep]
    else:
        temp_at_master = temp_df["temp_K"].to_numpy()[keep]
        abs_at_master  = A_of_t(t_master_kept)

    # Optional time rebasing
    t_master = t_master_kept - t_master_kept[0] if (rebase_time and n_kept > 0) else t_master_kept

    aligned = pd.DataFrame({
        "time_s": t_master,
        "temp_K": temp_at_master,
        "abs":    abs_at_master
    })

    n_points = int(len(t_master))
    diag = {
        "stream": label_prefix,                 # 'baseline' or 'sample'
        "master": master,                       # 'abs' or 'temp'
        "n_points_raw": n_points_raw,           # number of datapoints kept before trimming
        "n_points_kept": n_kept,                # number of datapoints kept after trimming
        "frac_kept": (n_kept / n_points_raw) if n_points_raw else 0.0,
        "n_trimmed_low": n_trim_low,            # number of low t datapoints trimmed
        "n_trimmed_high": n_trim_high,          # number of high t datapoints trimmed
        "frac_trimmed_low": (n_trim_low / n_points_raw) if n_points_raw else 0.0,
        "frac_trimmed_high": (n_trim_high / n_points_raw) if n_points_raw else 0.0,
        "overhang_low_s":  overhang_low,        # seconds beyond the other stream's range at low end (raw)
        "overhang_high_s": overhang_high,       # seconds beyond the other stream's range at high end (raw)
        "median_dt_temp_s": m_dt_temp,
        "median_dt_abs_s":  m_dt_abs,
        "tmin_temp": float(temp_df["time_s"].iloc[0]),  # temperature at start
        "tmax_temp": float(temp_df["time_s"].iloc[-1]), # temperature at end
        "tmin_abs":  float(abs_df["time_s"].iloc[0]),   # absorbance at start
        "tmax_abs":  float(abs_df["time_s"].iloc[-1]),  # absorbance at end
        "time_rebased": bool(rebase_time),      # True: time rebased to start at t=0
        "trim_to_overlap": bool(trim_to_overlap),   # True: nonoverlapping data dropped
    }

    return aligned, diag


# ----------------------------
# Top-level for all four data streams
# ----------------------------

def align_all_streams(baseline_T, baseline_A, sample_T, sample_A, rebase_time=True, trim_to_overlap=True):
    """
    Align baseline and sample (absorbance+temperature) pairs independently (optional overlap trimming and time rebasing).
    
        Args:
            baseline_T (DataFrame): ['time_s','temp_K'] for solvent baseline
            baseline_A (DataFrame): ['time_s','abs'] for solvent baseline
            sample_T (DataFrame): ['time_s','temp_K'] for sample measurements
            sample_A (DataFrame): ['time_s','abs'] for sample measurements
            rebase_time (bool): if True subtract t0 so time starts at t=0, default True
            time_to_overlap (bool): if True drop non-overlapping data (based on time overlap), default True

        Returns:
            baseline_aligned (DataFrame): ['time_s','temp_K','abs'] on the chosen master time axis
            sample_aligned (DataFrame): ['time_s','temp_K','abs'] on the chosen master time axis
            diag_baseline (dict): diagnostics for aligning baseline data
            diag_sample (dict): diagnostics for aligning sample data
    """

    baseline_aligned, diag_baseline = time_align_T_and_A(
        baseline_T, baseline_A,
        label_prefix="baseline",
        rebase_time=rebase_time,
        trim_to_overlap=trim_to_overlap
    )

    sample_aligned, diag_sample = time_align_T_and_A(
        sample_T, sample_A,
        label_prefix="sample",
        rebase_time=rebase_time,
        trim_to_overlap=trim_to_overlap
    )
    
    return baseline_aligned, sample_aligned, diag_baseline, diag_sample