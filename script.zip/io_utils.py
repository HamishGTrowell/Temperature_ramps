# io.py

"""
CSV I/O with tolerant header parsing and unit normalisation.
"""

from pathlib import Path
import re
import pandas as pd
from scipy.constants import zero_Celsius
# local imports
import validate


CANONICAL_FILENAMES = {
    "baseline_temp": "baseline_temp.csv",
    "baseline_abs": "baseline_abs.csv",
    "sample_temp": "sample_temp.csv",
    "sample_abs": "sample_abs.csv",
} # default data file names for io.py to search for in input_folder


# ---------- File discovery ----------
def discover_input_files(input_folder):
    """
    Look for canonical filenames inside input_folder.

    Returns a dict with keys:
        'baseline_temp', 'baseline_abs', 'sample_temp', 'sample_abs'
    and values corresponding to their file paths.
    """
    input_folder = Path(input_folder)
    if not input_folder.exists():
        raise FileNotFoundError(f"Input folder does not exist: {input_folder}")

    found = {}
    for key, fname in CANONICAL_FILENAMES.items():
        candidate = input_folder / fname
        if candidate.exists():
            found[key] = candidate
        else:
            raise FileNotFoundError(f"Input file does not exist: {fname}")

    return found


# ---------- Header parsing ----------
_TIME_PATTERNS = [
    r"time", r"t"
]
_TIME_UNITS = [
    r"s", r"sec", r"second", r"seconds", r"min", r"minute", r"minutes"
]

_TEMP_PATTERNS = [
    r"temp", r"temperature", r"t"  # allow T; rely on units to disambiguate from time
]
_TEMP_UNITS = [
    r"k", r"kelvin", r"c", r"degc", r"°c", r"celsius"
]

_ABS_PATTERNS = [
    r"absorbance", r"abs"
]
_ABS_UNITS = [
    r"a\.?u\.?", r"au"
]

def _compile_header_regex(names, units):
    """
    Build a regex that matches:
      - name (case-insensitive)
      - optional whitespace before units e.g. 'time(s)' or 'time (s)'
      - units in () or []
    """
    name_group = r"(?:%s)" % "|".join(names)
    unit_group = r"(?:%s)" % "|".join(units)

    # Require unit in parentheses OR square brackets, allow optional spaces
    pattern = rf"^\s*{name_group}\s*(?:\(\s*{unit_group}\s*\)|\[\s*{unit_group}\s*\])\s*$"

    return re.compile(pattern, flags=re.IGNORECASE)

_RE_TIME_WITH_UNITS = _compile_header_regex(_TIME_PATTERNS, _TIME_UNITS)
_RE_TEMP_WITH_UNITS = _compile_header_regex(_TEMP_PATTERNS, _TEMP_UNITS)
_RE_ABS = _compile_header_regex(_ABS_PATTERNS, _ABS_UNITS)

# Extract token inside parentheses, tolerant to "X(y)" or "X (y)"
_RE_EXTRACT_UNIT = re.compile(r"(?:\((.*?)\)|\[(.*?)\])")

def _extract_unit_token(header):
    m = _RE_EXTRACT_UNIT.search(header)
    if not m:
        return None
    # If parentheses matched, group(1) is set; if brackets matched, group(2) is set
    token = m.group(1) if m.group(1) is not None else m.group(2)
    return token.strip().lower()

def _detect_semantic_columns(columns):
    """
    From a list of header strings, detect which column is time, temperature, absorbance.
    Returns:
        {
          'time': (original_colname, unit_token),
          'temp': (original_colname, unit_token) or None,
          'abs':  (original_colname, unit_token) or None
        }
    """
    time_col = None
    time_unit = None
    temp_col = None
    temp_unit = None
    abs_col = None
    abs_unit = None

    for col in columns:
        c = col.strip()
        if time_col is None and _RE_TIME_WITH_UNITS.match(c):
            time_col = col
            time_unit = _extract_unit_token(c)
            continue
        if temp_col is None and _RE_TEMP_WITH_UNITS.match(c):
            temp_col = col
            temp_unit = _extract_unit_token(c)
            continue
        if abs_col is None and _RE_ABS.match(c):
            abs_col = col
            abs_unit = _extract_unit_token(c)
            continue

    if time_col is None:
        raise ValueError(
            f"Could not detect a time column from headers: {columns}. "
            f"Accepted examples: 'Time (s)', 'Time (min)', 't (s)', 't (min)'."
        )
    if temp_col is None and abs_col is None:
        raise ValueError(
            f"Could not detect temperature or absorbance column from headers: {columns}. "
            f"Accepted temperature examples: 'Temp (K)', 'Temperature (C)'. "
            f"Accepted absorbance examples: 'Absorbance (a.u.)', 'Abs (au)'."
        )
    if temp_col is not None and abs_col is not None:
        raise ValueError(
            f"Ambiguous CSV: found BOTH temperature and absorbance columns in {columns}. "
            f"Each file should contain either (time, temperature) OR (time, absorbance)."
        )

    return {
        "time": (time_col, time_unit),
        "temp": (temp_col, temp_unit) if temp_col is not None else None,
        "abs": (abs_col, abs_unit) if abs_col is not None else None,
    }


# ---------- Reading & unit conversion ----------
def read_csv_with_units(path, sample_every=1):
    """
    Read a CSV with tolerant header parsing. Returns:
        df_raw: as read, with original column names
        meta: {
            'time_col', 'time_unit',
            'temp_col', 'temp_unit',
            'abs_col',  'abs_unit'
        }
    Optional:
        sample_every: int (default 1). Use every nth row for testing sparse data.
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"CSV not found: {path}")

    df = pd.read_csv(path)  # comma-separated
    if df.shape[1] < 2:
        raise ValueError(f"Expected at least 2 columns in {path}, got {df.shape[1]}")
    if df.shape[1] > 2:
        print(f"WARNING: Expected 2 columns in {path}, got {df.shape[1]}.")

    if sample_every > 1:
        df = df.iloc[::sample_every].reset_index(drop=True)

    colmap = _detect_semantic_columns(list(df.columns))

    meta = {
        "time_col": colmap["time"][0],
        "time_unit": colmap["time"][1],
        "temp_col": colmap["temp"][0] if colmap["temp"] else None,
        "temp_unit": colmap["temp"][1] if colmap["temp"] else None,
        "abs_col": colmap["abs"][0] if colmap["abs"] else None,
        "abs_unit": colmap["abs"][1] if colmap["abs"] else None,
    }
    return df, meta


def _normalize_time_to_seconds(series, unit_token):
    """
    Convert time to seconds. Accepts 's','sec','second','seconds','min','minute','minutes'.
    """
    if unit_token == None:
        raise ValueError(f"Unrecognized time unit.")
    u = unit_token.strip().lower()
    if u in {"s", "sec", "second", "seconds"}:
        factor = 1.0
    elif u in {"min", "minute", "minutes"}:
        factor = 60.0
    else:
        raise ValueError(f"Unrecognized time unit '{unit_token}'.")
    return pd.to_numeric(series, errors="coerce") * factor


def _normalize_temp_to_kelvin(series, unit_token):
    """
    Convert temperature to kelvin.
    Recognized units: 'K','kelvin','C','degC','°C','celsius' (case/punct insensitive).
    """
    if unit_token == None:
        raise ValueError(f"Unrecognized temperature unit.")
    u = unit_token.strip().lower()
    if u in {"k", "kelvin"}:
        return pd.to_numeric(series, errors="coerce")
    if u in {"c", "degc", "°c", "celsius"}:
        return pd.to_numeric(series, errors="coerce") + zero_Celsius

    raise ValueError(f"Unrecognized temperature unit '{unit_token}'.")


def convert_to_SI(df_raw, meta):
    """
    Convert columns to SI and standard names:
      - time -> 'time_s'
      - temp -> 'temp_K' (if present)
      - abs  -> 'abs'    (dimensionless)
    Drops any extra columns and rows that fail numeric coercion.
    """
    tcol = meta["time_col"]
    time_s = _normalize_time_to_seconds(df_raw[tcol], meta["time_unit"])

    cols = {"time_s": time_s}

    if meta["temp_col"] is not None:
        T_K = _normalize_temp_to_kelvin(df_raw[meta["temp_col"]], meta["temp_unit"])
        cols["temp_K"] = T_K

    if meta["abs_col"] is not None:
        A = pd.to_numeric(df_raw[meta["abs_col"]], errors="coerce")
        cols["abs"] = A

    df_SI = pd.DataFrame(cols)
    df_SI = df_SI.dropna(subset=list(cols.keys())).reset_index(drop=True)
    return df_SI


# ---------- High-level loader ----------
def load_all_inputs(file_map):
    """
    Load and convert all four required CSVs to SI with standardized columns.
    Returns:
        baseline_T, baseline_A, sample_T, sample_A
    """
    # Baseline temperature
    df, meta = read_csv_with_units(file_map["baseline_temp"], sample_every=1)
    base_T = convert_to_SI(df, meta)
    if "temp_K" not in base_T.columns:
        raise ValueError("Baseline temperature file must contain a temperature column.")

    # Baseline absorbance
    df, meta = read_csv_with_units(file_map["baseline_abs"],sample_every=1)
    base_A = convert_to_SI(df, meta)
    if "abs" not in base_A.columns:
        raise ValueError("Baseline absorbance file must contain an absorbance column.")

    # Sample temperature
    df, meta = read_csv_with_units(file_map["sample_temp"],sample_every=1)
    samp_T = convert_to_SI(df, meta)
    if "temp_K" not in samp_T.columns:
        raise ValueError("Sample temperature file must contain a temperature column.")

    # Sample absorbance
    df, meta = read_csv_with_units(file_map["sample_abs"])
    samp_A = convert_to_SI(df, meta)
    if "abs" not in samp_A.columns:
        raise ValueError("Sample absorbance file must contain an absorbance column.")

    base_T = base_T[["time_s", "temp_K"]]
    base_A = base_A[["time_s", "abs"]]
    samp_T = samp_T[["time_s", "temp_K"]]
    samp_A = samp_A[["time_s", "abs"]]

    return base_T, base_A, samp_T, samp_A


# TESTING
if __name__ == "__main__":
    folder = "G:/projects/temp_ramp/program/example-data/"
    files = discover_input_files(folder)
    base_T, base_A, samp_T, samp_A = load_all_inputs(files)

    print("Baseline temp (head):")
    print(base_T.head())
    print("\nBaseline absorbance (head):")
    print(base_A.head())
    print("\nSample temp (head):")
    print(samp_T.head())
    print("\nSample absorbance (head):")
    print(samp_A.head())