# baseline.py
"""
Temperature-dependent solvent baseline corrections.
Based on data obtained by absorbance measured over a (linear) temperature ramp.
baseline.py is used to fit a temperature-dependent baseline and subtract this from sample data.
"""

import numpy as np
import pandas as pd
# local imports
import phases
import validate


def fit_baseline_coeffs(baseline_aligned_df, order=4):
    """
    Fit a polynomial on aligned absorbance baseline data.

        Args:
            baseline_aligned_df (DataFrame): ['time_s', 'temp_K', 'abs']
            order (int): polynomial degree for fitting, default 4

        Returns:
            model (dict): {
                "type" (str): "poly",
                "order" (int): order,
                "coeffs_descending" (1D array[floats]): fitted polynomial coefficients,
                "Tmin_fit" (float): minimum baseline temperature (K),
                "Tmax_fit" (float): maximum baseline temperature (K),
                "n_points" (int): number of baseline datapoints
            }
    """

    label = "baseline_aligned"
    
    # Validate for required columns
    validate.require_columns(baseline_aligned_df, ["time_s", "temp_K", "abs"], label)

    # Validate and extract numeric arrays
    T_fit = validate.validate_numeric_series(baseline_aligned_df["temp_K"], "temp_K", label)
    A_fit = validate.validate_numeric_series(baseline_aligned_df["abs"], "abs", label)

    # Need at least n+1 datapoints to fit polynomial of order n
    if len(T_fit) < (order + 1):
        raise ValueError(
            f"{label}: insufficient points ({len(T_fit)}) to fit polynomial of order {order} "
            f"(need at least {order + 1})."
        )

    # Fit polynomial in descending powers
    coeffs_desc = np.polyfit(T_fit, A_fit, deg=order)

    model = {
        "type": "poly",
        "order": int(order),
        "coeffs_descending": coeffs_desc,
        "Tmin_fit": float(np.min(T_fit)),
        "Tmax_fit": float(np.max(T_fit)),
        "n_points": int(len(T_fit)),
    }
    return model


def evaluate_baseline_poly(coeffs_descending, temps_K):
    """
    Evaluate fitted baseline absorbance at the provided temperatures.

        Args:
            coeffs_descending (1D array[float]): fitted polynomial coefficients for baseline(T) 
            temps_K (1D array[float]): temperatures (K) to evaluate baseline absorbance

        Returns:
            A_pred (1D array[float]): fitted baseline absorbance for each temperature 
    """

    Tq = np.asarray(temps_K, dtype=float)
    return np.polyval(coeffs_descending, Tq)


def compute_residuals(y_true, y_pred):
    """
    Compute residuals and simple fit diagnostics.

        Args:
            y_true (1D array[float]): true value
            y_pred (1D array[float]): predicted value

        Returns:
            resid (1D array[float]): residuals (true - predicted)
            stats (dict): { "rmse": float, "r2": float, "n": int number of datapoints}
    """
    y_t = np.asarray(y_true, dtype=float)
    y_p = np.asarray(y_pred, dtype=float)

    # arrays must have same number of datapoints
    if y_t.shape != y_p.shape:
        raise ValueError(f"compute_residuals: shape mismatch {y_t.shape} vs {y_p.shape}")

    resid = y_t - y_p
    n = int(y_t.size)
    ss_res = float(np.sum(resid * resid))
    mean_y = float(np.mean(y_t))
    ss_tot = float(np.sum((y_t - mean_y) ** 2))
    rmse = float(np.sqrt(ss_res / n)) if n > 0 else float("nan")
    r2 = float(1.0 - ss_res / ss_tot) if ss_tot > 0 else 1.0

    stats = {"rmse": rmse, "r2": r2, "n": n}
    return resid, stats

# ----------------------------
# Implementation - wrapper function to fit baseline, evaluate and compute residuals 
# ----------------------------

def fit_baseline_poly(baseline_aligned_df, order=4, use_up_ramp_only=True):
    """
    Fits baseline, evaluates baseline absorbances, calculates residuals

        Args:
            baseline_aligned_df (DataFrame): ["time_s", "temp_K", "abs"]
            order (int): polynomial degree for fitting, default 4
            use_up_ramp_only (bool): only use increasing temperature ramp for baseline fitting, default True

        Returns:
            model (dict): see fit_baseline_coeffs
            fit_df (DataFrame): ['temp_K', 'abs', 'abs_fit', 'residual']
            stats (dict): {'rmse','r2','n'}
    """

    df_fit = baseline_aligned_df
    ramp_diag = None

    if use_up_ramp_only:
        df_fit, ramp_diag = phases.select_up_ramp_segment(
            baseline_aligned_df,
            label="baseline_up_ramp"
        )
    
    model = fit_baseline_coeffs(df_fit, order=order)

    T_fit = np.asarray(df_fit["temp_K"], dtype=float)
    A_true = np.asarray(df_fit["abs"], dtype=float)
    A_pred = evaluate_baseline_poly(model["coeffs_descending"], T_fit)

    residuals, stats = compute_residuals(A_true, A_pred)

    fit_df = pd.DataFrame({
        "temp_K":   T_fit,
        "abs":      A_true,
        "abs_fit":  A_pred,
        "residual": residuals,
    })

    stats.update({
        "used_points": int(len(T_fit)),
        "ramp_selection": ramp_diag
    })

    return model, fit_df, stats


def apply_baseline_to_sample(sample_aligned_df, model):
    """
    Evaluate A_baseline(T) on aligned sample data and subtract it.

        Args:
            sample_aligned_df (DataFrame): ['time_s','temp_K','abs']
            model (dict): see fit_baseline_coeffs/fit_baseline_poly

        Returns:
            sample_corrected (DataFrame): ['time_s','temp_K','abs','A_baseline_at_T','abs_corr']
            eval_diag (dict): {
                'extrapolated_low' (bool): True if min sample temperature < baseline,
                'extrapolated_high' (bool): True if max sample temperature > baseline,
                'overhang_low_K' (float): extent of low temperature extrapolation,
                'overhang_high_K' (float): extent of high temperature extrapolation,
                'fit_Tmin_K' (float): minimum baseline temperature (K),
                'fit_Tmax_K' (float): maximum baseline temperature (K),
                'sample_Tmin_K' (float): minimum sample temperature (K),
                'sample_Tmax_K' (float): maximum sample temperature (K)
            }
    """

    label = "sample_aligned"
    
    # Check for required columns
    validate.require_columns(sample_aligned_df, ["time_s", "temp_K", "abs"], label)

    # Validate and extract numeric arrays 
    T_sample = validate.validate_numeric_series(sample_aligned_df["temp_K"], "temp_K", label)
    A_sample = validate.validate_numeric_series(sample_aligned_df["abs"],     "abs",     label)

    # Get polynomial coeffs and baseline temperature range
    coeffs = np.asarray(model["coeffs_descending"], dtype=float)
    Tmin_fit = float(model["Tmin_fit"])
    Tmax_fit = float(model["Tmax_fit"])

    # Evaluate baseline at sample temperatures (polynomial extrapolation permitted)
    A_base_at_T = evaluate_baseline_poly(coeffs, T_sample)

    # Corrected absorbance
    A_corr = A_sample - A_base_at_T

    # Extrapolation diagnostics
    T_min_sample = float(np.min(T_sample))
    T_max_sample = float(np.max(T_sample))
    extrap_low  = T_min_sample < Tmin_fit
    extrap_high = T_max_sample > Tmax_fit
    overhang_low_K  = float(max(0.0, Tmin_fit - T_min_sample))
    overhang_high_K = float(max(0.0, T_max_sample - Tmax_fit))

    eval_diag = {
        "extrapolated_low":  bool(extrap_low),
        "extrapolated_high": bool(extrap_high),
        "overhang_low_K":    overhang_low_K,
        "overhang_high_K":   overhang_high_K,
        "fit_Tmin_K":        Tmin_fit,
        "fit_Tmax_K":        Tmax_fit,
        "sample_Tmin_K":     T_min_sample,
        "sample_Tmax_K":     T_max_sample,
    }

    # Assemble output dataframe
    sample_corrected = sample_aligned_df.copy()
    sample_corrected["A_baseline_at_T"] = A_base_at_T
    sample_corrected["abs_corr"] = A_corr

    return sample_corrected, eval_diag


def get_baseline_callable(model):
    """
    Return a callable f(T) that evaluates the fitted baseline polynomial.
    """
    coeffs = np.asarray(model["coeffs_descending"], dtype=float)
    return lambda Tq: evaluate_baseline_poly(coeffs, Tq)