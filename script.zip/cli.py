# cli.py

"""
Command-line interface for the analysis workflow
"""

import sys
import argparse
from pathlib import Path

# local imports
import io_utils
import filters
import align
import plotting
import baseline
import phases
import calibration
import kinetics
import eyring

# ---- Argument validators ----
def positive_int(value: str) -> int:
    """Parse a positive integer (> 0)."""
    try:
        iv = int(value)
    except Exception as exc:
        raise argparse.ArgumentTypeError(f"must be an integer: {value}") from exc
    if iv <= 0:
        raise argparse.ArgumentTypeError(f"must be > 0 (got {iv})")
    return iv


def positive_odd_int(value: str) -> int:
    """Parse a positive odd integer (>= 3)."""
    iv = positive_int(value)
    if iv < 3 or iv % 2 == 0:
        raise argparse.ArgumentTypeError(f"must be an odd integer >= 3 (got {iv})")
    return iv


def non_negative_float(value: str) -> float:
    """Parse a non-negative float (>= 0)."""
    try:
        fv = float(value)
    except Exception as exc:
        raise argparse.ArgumentTypeError(f"must be a number: {value}") from exc
    if fv < 0:
        raise argparse.ArgumentTypeError(f"must be >= 0 (got {fv})")
    return fv


def positive_float(value: str) -> float:
    """Parse a positive float (> 0)."""
    fv = non_negative_float(value)
    if fv == 0:
        raise argparse.ArgumentTypeError("must be > 0 (got 0)")
    return fv





def parse_args(argv=None):
    p = argparse.ArgumentParser(
        prog="temp-ramp-cli",
        description="CLI to analyse temperature-ramp UV-Vis data."
    )

    # --- io_utils.py args ---
    p.add_argument("input_folder",
                   help="Folder containing baseline_temp.csv, baseline_abs.csv, sample_temp.csv, sample_abs.csv")

    # !!! WARNING: fallbacks not yet added to io_utils.py!!!
    # --- Optional explicit file paths (fallbacks/overrides) ---
    p.add_argument("--baseline-temp", dest="baseline_temp", default=None,
                   help="Explicit path to baseline_temp.csv")
    p.add_argument("--baseline-abs", dest="baseline_abs", default=None,
                   help="Explicit path to baseline_abs.csv")
    p.add_argument("--sample-temp", dest="sample_temp", default=None,
                   help="Explicit path to sample_temp.csv")
    p.add_argument("--sample-abs", dest="sample_abs", default=None,
                   help="Explicit path to sample_abs.csv")

    # --- filters.py args ---
    p.add_argument("--abs-window", type=positive_odd_int, default=61,
                   help="Hampel window size (points) for absorbance anomalies (default: 61)")
    p.add_argument("--abs-n-sigma", type=positive_float, default=3.0,
                   help="Hampel threshold in sigma units for absorbance anomalies (default: 3.0)")
    p.add_argument("--temp-jump-K-per-min", type=positive_float, default=20.0,
                   help="Temperature jump threshold in K/min for temperature anomalies (default: 20)")

    # --- align.py args ---
    p.add_argument("--no-align-trim", dest="align_trim_to_overlap",
               action="store_false",
               help="Do NOT trim to overlap window before interpolation")
    p.set_defaults(align_trim_to_overlap=True)
    p.add_argument("--no-rebase-time", dest="rebase_time",
               action="store_false",
               help="Do NOT rebase time; keep absolute times from input")
    p.set_defaults(rebase_time=True)

    # --- baseline.py args ---
    p.add_argument("--baseline-order", type=positive_int, default=4,
               help="Polynomial degree for baseline A(T) fit (default: 4)")
    p.add_argument("--baseline-use-full-ramp", dest="baseline_use_up_ramp_only",
               action="store_false",
               help="Fit baseline using full baseline data instead of only the increasing-T ramp (default: off)")
    p.set_defaults(baseline_use_up_ramp_only=True)

    # --- phases.py args ---
    p.add_argument("--phase-window", type=positive_int, default=10,
               help="Smoothing window (points) for smoothed T used to locate the hold (default: 10)")
    p.add_argument("--phase-band-K", type=positive_float, default=0.1,
               help="Half-band (K) around smoothed peak defining the hold (default: 0.1 K)")
    p.add_argument("--no-hold", dest="phase_use_hold", action="store_false",
               help="Disable hold detection; split only at smoothed Tmax")
    p.set_defaults(phase_use_hold=True)


    # --- calibration.py args ---
    p.add_argument("--path-length", type=float, default=1.0,
                   help="Optical path length in cm (default: 1.0)") # needs converting to SI
    p.add_argument("--concentration", type=float, default=None,
                   help="Total concentration in micromolar") # needs converting to SI
    p.add_argument("--calib-order", type=int, default=2,
               help="Polynomial order for calibration fit on down-ramp (default: 2)")

    # --- kinetics.py args ---
    p.add_argument("--model", choices=["eyring", "arrhenius"], default="eyring",
                help="Kinetics model for k(T): Eyring or Arrhenius (default: eyring)")

    p.add_argument("--thalf-K", type=float, default=298.15,
                help="Reference temperature (K) for reporting t1/2 and ΔG‡ (default: 298.15)")

    p.add_argument("--eps-T-K", type=float, default=298.15,
                help="Single temperature (K) at which to report ε_E (M^-1 cm^-1). Default: 298.15")

    p.add_argument("--kin-weighting", choices=["uniform"], default="uniform",
                help="Residual weighting for SSR (currently only 'uniform').")

    p.add_argument("--de-maxiter", type=int, default=4000, help="Differential evolution max iterations (default: 400)")
    p.add_argument("--de-popsize", type=positive_int, default=15, help="Differential evolution population size (default: 15)")
    p.add_argument("--de-tol", type=positive_float, default=1e-6, help="Differential evolution convergence tolerance (default: 1e-6)")
    p.add_argument("--de-workers", type=positive_int, default=1, help="Workers for differential evolution (1=serial).")

    # --- eyring.py args ---
    p.add_argument("--eyring-smooth-pts", type=int, default=3,
                help="Centered MA window (points) applied to BOTH A(t) and T(t) before derivatives.")
    p.add_argument("--eyring-avg-pts", type=int, default=3,
                help="Rolling average window (points) for ln(k/T) along 1/T (visual de-noising).")
    p.add_argument("--eyring-fZ-min", type=float, default=0.02,
                help="Lower bound for fZ kept (drop extremes).")
    p.add_argument("--eyring-fZ-max", type=float, default=0.98,
                help="Upper bound for fZ kept (drop extremes).")
    p.add_argument("--eyring-min-lever", type=float, default=1e-4,
                help="Minimum |(A_Z* - A_E) * fZ| to keep a point.")

    # --- plotting.py args ---
    p.add_argument("--show-plots", action="store_true",
               help="Show plots interactively")
    p.add_argument("--save-plots", default=None,
               help="Directory or file path to save plots")

    # --- Experimental metadata args ---
    p.add_argument("--compound-name", default=None,
                   help="[METADATA] Compound name/ID")
    p.add_argument("--preirradiation-wavelength-nm", type=float, default=None,
                   help="[METADATA] Pre-irradiation wavelength (nm)")
    p.add_argument("--prog-ramp-up-K-per-min", type=positive_float, default=None,
                   help="[METADATA] Programmed ramp-up rate (K/min)")
    p.add_argument("--prog-hold-time-s", type=non_negative_float, default=None,
                   help="[METADATA] Programmed isothermal hold time (s)")
    p.add_argument("--prog-ramp-down-K-per-min", type=positive_float, default=None,
                   help="[METADATA] Programmed ramp-down rate (K/min)")
    p.add_argument("--uvvis-meas-interval-s", type=positive_float, default=None,
                   help="[METADATA] UV-Vis measurement interval / integration time (s)")
    p.add_argument("--pathlength-cm", "--pathlength",
        dest="pathlength_cm", type=float, default=1.0,
        help="Optical path length (cm). Required for reporting ε."
    )
    p.add_argument(
        "--concentration-uM", "--conc-uM",
        dest="concentration_uM", type=float, default=50.0,
        help="Total chromophore concentration (µM) at reference temperature. Required for reporting ε."
    )
    p.add_argument(
        "--conc-T-K", dest="conc_T_K", type=float, default=298.15,
        help="Temperature (K) at which concentration is specified (metadata only; default 298.15 K)."
    )

    # --- Additional arguments ---
    p.add_argument("--quiet", action="store_true",
                   help="Suppress most console output")

    return p.parse_args(argv)


def build_file_map(input_folder, args):
    files = io_utils.discover_input_files(input_folder)

    #! Overides not yet added
    overrides = {
        "baseline_temp": args.baseline_temp,
        "baseline_abs": args.baseline_abs,
        "sample_temp": args.sample_temp,
        "sample_abs": args.sample_abs,
    }
    for k, v in overrides.items():
        if v is not None:
            p = Path(v)
            if not p.exists():
                raise FileNotFoundError(f"Explicit path for '{k}' not found: {p}")
            files[k] = p

    return files

def print_metadata(args):
    if not args.quiet:
        print("\n===== Experimental metadata =====")
        meta_pairs = [
            ("compound_name", args.compound_name),
            ("concentration", args.concentration),
            ("path_length", args.path_length),
            ("preirradiation_wavelength_nm", args.preirradiation_wavelength_nm),
            ("prog_ramp_up_K_per_min", args.prog_ramp_up_K_per_min),
            ("prog_hold_time_s", args.prog_hold_time_s),
            ("prog_ramp_down_K_per_min", args.prog_ramp_down_K_per_min),
            ("uvvis_meas_interval_s", args.uvvis_meas_interval_s),
            ("model", args.model),
            ("thalf_K", args.thalf_K),
            ("plots", args.show_plots),
        ]
        for k, v in meta_pairs:
            if v is not None:
                print(f"{k:>30}: {v}")




def main(argv=None):
    args = parse_args(argv)



    # --- Argument validation ---
    if args.de_popsize is not None and args.de_popsize < 5:
        print("ERROR: --de-popsize must be >= 5.", file=sys.stderr)
        return 2
    if args.baseline_order is not None and args.baseline_order < 1:
        print("ERROR: --baseline-order must be >= 1.", file=sys.stderr)
        return 2
    if args.phase_window is not None and args.phase_window < 1:
        print("ERROR: --phase-window must be >= 1.", file=sys.stderr)
        return 2
    if args.abs_window is not None and (args.abs_window < 3 or args.abs_window % 2 == 0):
        print("ERROR: --abs-window must be an odd integer >= 3.", file=sys.stderr)
        return 2
    input_folder = Path(args.input_folder)
    if not input_folder.exists():
        print(f"ERROR: input folder does not exist: {input_folder}", file=sys.stderr)
        return 2

    # Show metadata (optional)
    print_metadata(args)

    # Discover/override files
    try:
        files = build_file_map(input_folder, args)
    except Exception as e:
        print(f"ERROR discovering files: {e}", file=sys.stderr)
        return 3

    # Load CSVs (to SI units)
    try:
        base_T, base_A, samp_T, samp_A = io_utils.load_all_inputs(files)
    except Exception as e:
        print(f"ERROR loading inputs: {e}", file=sys.stderr)
        return 4

    if not args.quiet:
        print("\n===== Loaded data (SI) =====")
        print(f"{'baseline_temp':>16}: {len(base_T)} rows")
        print(f"{'baseline_abs':>16}: {len(base_A)} rows")
        print(f"{'sample_temp':>16}: {len(samp_T)} rows")
        print(f"{'sample_abs':>16}: {len(samp_A)} rows")

    # Filter streams
    try:
        base_T_f, base_A_f, samp_T_f, samp_A_f = filters.filter_all_streams(
            base_T, base_A, samp_T, samp_A,
            abs_window=args.abs_window,
            abs_n_sigma=args.abs_n_sigma,
            temp_jump_K_per_min=args.temp_jump_K_per_min,
            verbose=(not args.quiet),
        )
    except Exception as e:
        print(f"ERROR during filtering: {e}", file=sys.stderr)
        return 5
    
    # Align streams
    try:
        baseline_aligned, sample_aligned, diag_base, diag_samp = align.align_all_streams(
        base_T_f, base_A_f, samp_T_f, samp_A_f,
        rebase_time=args.rebase_time,
        trim_to_overlap=args.align_trim_to_overlap
        )
    except Exception as e:
        print(f"ERROR during alignment: {e}", file=sys.stderr)
        return 6

    if not args.quiet:
        print("\n===== Alignment diagnostics =====")
        for d in (diag_base, diag_samp):
            print(
                f"{d['stream']:>10} | master={d['master']}, "
                f"raw={d['n_points_raw']}, kept={d['n_points_kept']} ({d['frac_kept']:.2%}), "
                f"trim_low={d['n_trimmed_low']} ({d['frac_trimmed_low']:.2%}), "
                f"trim_high={d['n_trimmed_high']} ({d['frac_trimmed_high']:.2%}), "
                f"overhang_low={d['overhang_low_s']:.3g}s, overhang_high={d['overhang_high_s']:.3g}s, "
                f"time_rebased={'Yes' if d['time_rebased'] else 'No'}, "
                f"trim_to_overlap={'Yes' if d['trim_to_overlap'] else 'No'}"
            )

    # Baseline
    try:
        model, fit_df, fit_stats = baseline.fit_baseline_poly(
            baseline_aligned, order=args.baseline_order, use_up_ramp_only=args.baseline_use_up_ramp_only
        )
    except Exception as e:
        print(f"ERROR during baseline fitting: {e}", file=sys.stderr)
        return 7

    try:
        sample_corrected, eval_diag = baseline.apply_baseline_to_sample(
            sample_aligned, model
        )
    except Exception as e:
        print(f"ERROR during baseline subtraction: {e}", file=sys.stderr)
        return 8

    if not args.quiet:
        rs = fit_stats.get("ramp_selection")
        print("\n===== Baseline fit =====")
        
        if rs is not None:
            print(f"Baseline up-ramp: kept {rs['n_kept']}/{rs['n_raw']} "
                f"({rs['frac_kept']:.1%})")
        else:
            print("Baseline up-ramp: (not applied)")
        
        print(f"order={model['order']}, points={model['n_points']}, "
            f"T_fit=[{model['Tmin_fit']:.2f}, {model['Tmax_fit']:.2f}] K, "
            f"RMSE={fit_stats['rmse']:.4g}, R^2={fit_stats['r2']:.4f}")

        print("===== Baseline evaluation on sample =====")
        print(f"Sample T=[{eval_diag['sample_Tmin_K']:.2f}, {eval_diag['sample_Tmax_K']:.2f}] K "
            f"vs fit domain [{eval_diag['fit_Tmin_K']:.2f}, {eval_diag['fit_Tmax_K']:.2f}] K")
        if eval_diag["overhang_low_K"] > 0 or eval_diag["overhang_high_K"] > 0:
            print(f"Extrapolation: low={eval_diag['overhang_low_K']:.2f} K, "
                f"high={eval_diag['overhang_high_K']:.2f} K")
            if eval_diag["overhang_low_K"] > 5 or eval_diag["overhang_high_K"] > 5:
                print("Suggestion: run a wider baseline (overhang > 5 K).")
            else:
                print("Note: small extrapolation applied (< 5 K); likely OK.")

    # Phases
    try:
        (masks, dfs, phase_diag) = phases.detect_sample_phases(
            sample_corrected,
            smooth_window_pts=args.phase_window,
            band_K=args.phase_band_K,
            use_hold=args.phase_use_hold,
        )
        mask_up, mask_hold, mask_down = masks
        sample_up_corr, sample_hold_corr, sample_down_corr = dfs
    except Exception as e:
        print(f"ERROR during phase detection: {e}", file=sys.stderr)
        return 9

    if not args.quiet:
        print("\n===== Sample phase detection (band around smoothed peak) =====")
        print(f"Hold indices: {phase_diag['indices']['hold_L']}..{phase_diag['indices']['hold_R']}  "
            f"({phase_diag['counts']['hold']} pts, {phase_diag['durations_s']['hold']:.1f} s)")
        print(f"Params: window={phase_diag['params']['smooth_window_pts']} pts, "
            f"band={phase_diag['params']['band_K']} K, "
            f"use_hold={phase_diag['params']['use_hold']}")

    # Calibration
    try:
        model_cal, fit_df_cal, stats_cal = calibration.fit_calibration_poly(
            sample_down_corr, order=args.calib_order
        )
    except Exception as e:
        print(f"ERROR during calibration fit: {e}", file=sys.stderr)
        return 10

    if not args.quiet:
        print("\n===== Calibration (down-ramp) =====")
        print(f"order={model_cal['order']}, points={model_cal['n_points']}, "
            f"T_fit=[{model_cal['Tmin_fit']:.2f}, {model_cal['Tmax_fit']:.2f}] K, "
            f"RMSE={stats_cal['rmse']:.4g}, R^2={stats_cal['r2']:.4f}")

    # Kinetics
    try:
        kin_results = kinetics.fit_kinetics(
            df_up=sample_up_corr,
            df_hold_or_none=sample_hold_corr,                 # may be empty/None; see use_hold below
            calib_model=model_cal,
            kin_model=args.model,
            thalf_K=args.thalf_K,
            eps_report_T_K=args.eps_T_K,
            weighting=args.kin_weighting,                     # currently only 'uniform'
            use_hold=args.phase_use_hold,                     # reuse your phases flag to include/exclude hold
            pathlength_cm=args.pathlength_cm,
            concentration_uM=args.concentration_uM,
            conc_ref_T_K=(args.conc_T_K if hasattr(args, "conc_T_K") and args.conc_T_K else 298.15),
            de_maxiter=args.de_maxiter,
            de_popsize=args.de_popsize,
            de_tol=args.de_tol,
            de_workers=args.de_workers,
        )
    except Exception as e:
        print(f"ERROR during kinetics fit: {e}", file=sys.stderr)
        return 11

    if not args.quiet:
        print("\n===== Kinetics fit =====")
        print(f"Model: {kin_results['model']['type']}")
        # params
        for k, v in kin_results["params"].items():
            print(f"{k}: {v:.6g}")
        # derived
        der = kin_results["derived"]
        print(f"k({der['thalf_K']:.2f} K): {der['k_at_Tref_s_inv']:.6g} s^-1")
        print(f"t1/2({der['thalf_K']:.2f} K): {der['t_half_display']['value']:.4g} {der['t_half_display']['unit']}")
        if der.get("dG_ref_J_per_mol") is not None:
            print(f"ΔG‡({der['thalf_K']:.2f} K): {der['dG_ref_J_per_mol']:.6g} J/mol")

        # extinction (decadic, M^-1 cm^-1)
        ext = kin_results["extinction_decadic"]
        print(f"ε_E({ext['eps_Tref_K']:.2f} K): {ext['epsilon_E_Minv_cmInv_at_Tref']:.6g} M^-1 cm^-1")
        print(f"ε_Z: {ext['epsilon_Z_Minv_cmInv']:.6g} M^-1 cm^-1")

        # diagnostics
        diag = kin_results["diagnostics"]
        opt = diag["optimizer"]
        print(f"SSR: {opt['ssr']:.6g} | success={opt['success']} | iters={opt['nit']} | evals={opt['nfev']}")
        cd = diag["calibration_domain"]
        if cd["low_extrap_K"] > 0 or cd["high_extrap_K"] > 0:
            print(f"Calibration A_E(T) extrapolation: {cd['low_extrap_K']:.2f} K below, {cd['high_extrap_K']:.2f} K above. "
                f"(Fit range: [{cd['calib_Tmin']:.2f}, {cd['calib_Tmax']:.2f}] K)")
        if diag["near_bounds_flags"]:
            print("Parameters near bounds:")
            for f in diag["near_bounds_flags"]:
                print(f"  - index {f['index']}: {f['value']:.6g} near {f['near']} bound [{f['lower']:.6g}, {f['upper']:.6g}]")
    
    # eyring fitting
    try:
        A_Z_star = kin_results["params"]["A_Z_star"]

        eyr_pts, e_diag = eyring.eyring_points_from_segments(
            df_up=sample_up_corr,
            df_hold_or_none=sample_hold_corr,
            calib_model=model_cal,
            A_Z_star=A_Z_star,
            use_hold=args.phase_use_hold,
            smooth_pts_A=args.eyring_smooth_pts,
            smooth_pts_T=args.eyring_smooth_pts,
            clip_fZ=(args.eyring_fZ_min, args.eyring_fZ_max),
            min_lever=args.eyring_min_lever,
            avg_pts=args.eyring_avg_pts,
        )

        if not args.quiet:
            print("\n===== Local Eyring points =====")
            print(f"points={e_diag['n_points']} "
                f"(smooth_A={e_diag['smooth_pts_A']}, smooth_T={e_diag['smooth_pts_T']}, "
                f"avg={e_diag['avg_pts']}, fZ in [{e_diag['clip_fZ'][0]:.2f},{e_diag['clip_fZ'][1]:.2f}], "
                f"min_lever={e_diag['min_lever']:.2e})")
    except Exception as e:
        eyr_pts = None
        print("Eyring points not generated")
    
    # Plotting
    if args.show_plots or args.save_plots:
        try:
            # Sample raw abs and temp data
            plotting.plot_sample_raw_temp_abs_dual(
                samp_T, samp_A,
                time_unit="s",
                show=args.show_plots,
                savepath=args.save_plots,
            )

            """
            # Sample raw abs data
            plotting.plot_sample_abs_vs_time_raw(
                sample_abs_df=samp_A,
                show=args.show_plots,
                savepath=args.save_plots,
                style_overrides=None,
               )
            
            # baseline raw abs data
            plotting.plot_baseline_abs_vs_time_raw(
                baseline_abs_df=base_A,
                show=args.show_plots,
                savepath=args.save_plots,
                style_overrides=None,
            )
            """

            # Sample filtered and aligned abs and temp data
            plotting.plot_sample_temp_abs_vs_time(
                sample_aligned,
                time_unit="s",
                show=args.show_plots,
                savepath=args.save_plots
            )

            # Baseline raw abs and temp data
            plotting.plot_baseline_raw_temp_abs_dual(
                base_T, base_A,
                time_unit="s",
                show=args.show_plots,
                savepath=args.save_plots,
            )

            # Baseline filtered and aligned abs and temp data
            plotting.plot_baseline_temp_abs_vs_time(
                baseline_aligned,
                time_unit="s",
                show=args.show_plots,
                savepath=args.save_plots
            )

            plotting.plot_baseline_abs_vs_temp_with_fit(
                baseline_aligned_df=baseline_aligned,
                model=model,
                show=args.show_plots,
                savepath=args.save_plots,
            )

            plotting.plot_baseline_residuals(
                fit_df,
                show=args.show_plots,
                savepath=args.save_plots,
            )

            plotting.plot_section_up_time_abs_temp(
                sample_up_corr, show=args.show_plots, savepath=args.save_plots
            )

            if sample_hold_corr is not None and len(sample_hold_corr) > 0:
                plotting.plot_section_hold_time_abs_temp(
                    sample_hold_corr, show=args.show_plots, savepath=args.save_plots
                )
            else:
                if not args.quiet:
                    print("[plot] Hold section empty — skipping hold plot.")
        
            plotting.plot_section_down_time_abs_temp(
                sample_down_corr, show=args.show_plots, savepath=args.save_plots
            )

            plotting.plot_calibration_abs_vs_temp_with_fit(
                sample_down_corr, model_cal, show=args.show_plots, savepath=args.save_plots
            )
            plotting.plot_calibration_residuals(
                fit_df_cal, show=args.show_plots, savepath=args.save_plots
            )

            plotting.plot_kinetics_abs_vs_time(
                kin_results["fit"],
                show=args.show_plots,
                savepath=args.save_plots,
            )

            # eyring plot not complete
            """
            if eyr_pts is not None and len(eyr_pts) > 0:
                plotting.plot_eyring_points(
                    eyr_pts,
                    show=args.show_plots,
                    savepath=args.save_plots,
                )
            else:
                if not args.quiet:
                    print("[plot] No Eyring points to plot — skipping.")
            """

        except Exception as e:
            print(f"WARNING: plotting failed: {e}", file=sys.stderr)


    return 0


if __name__ == "__main__":
    sys.exit(main())
