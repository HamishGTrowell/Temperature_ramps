# calibration.py

"""
Polynomial calibration fitting for absorbance vs temperature in down-ramp.
Required to model eps(E) vs temperature.
"""

import numpy as np
import pandas as pd
# local imports
import validate


def fit_calibration_coeffs(down_df, order=2):
    """
    Fit polynomial coefficients for A_calib(T) using down-ramp data.
    
        Args:
            down_df (DataFrame): ["time_s", "temp_K", "abs_corr"]
            order (int): polynomial degree for fitting, default 2
    
        Returns:
            model (dict): {
                type (str): "poly",
                order (int): polynomial degree for fitting,
                coeffs_descending (1D array[floats]): fitted polynomial coefficients,
                Tmin_fit (float): minimum down-ramp temperature (K),
                Tmax_fit (float): maximum down-ramp temperature (K),
                n_points (int): number of datapoints in down-ramp
    """

    # Data validation
    validate.check_aligned_triplet(down_df, label="calibration/down")
    validate.require_columns(down_df, ["abs_corr"], "calibration/down")

    # Validate and extract numeric arrays
    T = validate.validate_numeric_series(down_df["temp_K"], "temp_K", "calibration/down")
    A = validate.validate_numeric_series(down_df["abs_corr"], "abs_corr", "calibration/down")

    # Need at least n+1 datapoints to fit polynomial of order n
    if T.size < order + 1:
        raise ValueError(f"calibration/down: not enough points ({T.size}) to fit order {order} polynomial")

    # Fit polynomial in descending powers
    coeffs_desc = np.polyfit(T, A, order)

    model = {
        "type": "poly",
        "order": int(order),
        "coeffs_descending": coeffs_desc,
        "Tmin_fit": float(np.min(T)),
        "Tmax_fit": float(np.max(T)),
        "n_points": int(T.size),
    }

    return model


def evaluate_calibration_poly(coeffs_descending, T_query):
    """
    Evaluate fitted down-ramp absorbance at the provided temperatures.

        Args:
            coeffs_descending (1D array[float]): fitted polynomial coefficients for down-ramp absorbance(T) 
            T_query (1D array[float]): temperatures (K) to evaluate down-ramp absorbance
    """

    coeffs = np.asarray(coeffs_descending, dtype=float)
    Tq = np.asarray(T_query, dtype=float)
    return np.polyval(coeffs, Tq)


def compute_residuals(y_true, y_pred):
    """
    Compute residuals and simple fit diagnostics.

        Args:
            y_true (1D array[float]): true value
            y_pred (1D array[float]): predicted value

        Returns:
            resid (1D array[float]): residuals (true - predicted)
            stats (dict): { "rmse": float, "r2": float}
    """

    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    resid = y_true - y_pred
    rmse = float(np.sqrt(np.mean(resid**2))) if resid.size else float("nan")

    var = np.sum((y_true - np.mean(y_true))**2)
    ss_res = np.sum(resid**2)
    r2 = float(1.0 - ss_res / var) if var > 0 else float("nan")

    stats = {"rmse": rmse, "r2": r2}
    return resid, stats


def fit_calibration_poly(down_df, order=2):
    """
    Fits down-ramp, evaluates down-ramp absorbances, calculates residuals

        Args:
            down_df (DataFrame): ["time_s", "temp_K", "abs_corr"]
            order (int): polynomial degree for fitting, default 2

        Returns:
            model (dict): see fit_calibration_coeffs
            fit_df (DataFrame): ['temp_K', 'abs_corr', 'abs_fit', 'residual']
            stats (dict): {'rmse','r2'}
    """

    model = fit_calibration_coeffs(down_df, order=order)

    T_fit = np.asarray(down_df["temp_K"], dtype=float)
    A_true = np.asarray(down_df["abs_corr"], dtype=float)
    A_pred = evaluate_calibration_poly(model["coeffs_descending"], T_fit)

    residuals, stats = compute_residuals(A_true, A_pred)

    fit_df = pd.DataFrame({
        "temp_K":  T_fit,
        "abs_corr":     A_true,
        "abs_fit": A_pred,
        "residual": residuals,
    })

    return model, fit_df, stats