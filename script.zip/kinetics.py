# kinetics.py

"""
Kinetic model and fitting utilities
"""

import numpy as np
import pandas as pd
from scipy import constants as sc
from scipy.optimize import differential_evolution
from scipy.integrate import cumulative_trapezoid
# local imports
import validate


def validate_fit_segment(df, label):
    """
    Validate a fit segment DataFrame for increasing time and required columns.

        Args:
            df (DataFrame): ['time_s', 'temp_K' and either 'abs' or 'abs_corr']
            label (str): Used in error messages

        Returns:
            Raises ValueError on invalid input
    """

    validate.check_aligned_triplet(df, label)
    if "abs_corr" not in df.columns:
        raise ValueError(f"{label}: requires 'abs_corr' column (baseline-corrected absorbance).")
    
    validate.validate_numeric_series(df["time_s"], "time_s", label)
    validate.validate_numeric_series(df["temp_K"], "temp_K", label)
    validate.validate_numeric_series(df["abs_corr"], "abs_corr", label)


def concat_fit_segments(df_up, df_hold_or_none, use_hold):
    """
    Concatenate up-ramp and optional hold segments for fitting.

        Args:
            df_up (DataFrame): Up-ramp segment (aligned)
            df_hold_or_none (DataFrame): Hold segment or None
            use_hold (bool): if True and a hold segment is provided, include it

        Returns:
            df_fit (DataFrame): Combined segment with monotonically increasing 'time_s' and corresponding 'temp_K' and absorbance.
    """
    
    if use_hold and df_hold_or_none is not None and len(df_hold_or_none) > 0:
        df_fit = pd.concat([df_up, df_hold_or_none], axis=0, ignore_index=True)
    else:
        df_fit = df_up.copy()
    
    validate.validate_time_monotonic(df_fit, time_col="time_s", label="kinetics/fit", strict=True)
    
    return df_fit


def make_AE_evaluator_from_calibration(calib_model):
    """
    Create a function A_E(T) from a calibration model.

        Args:
            calib_model (dict): calibration model containing 'coeffs_descending'

        Returns:
            A_E_eval (func): A_E_eval(T_array) -> absorbance array
    """
    
    coeffs = np.asarray(calib_model["coeffs_descending"], dtype=float)
    
    def A_E_eval(T_array):
        return np.polyval(coeffs, np.asarray(T_array, dtype=float))
    
    return A_E_eval


def calibration_extrapolation_diag(calib_model, T_fit_min, T_fit_max):
    """
    Report how far evaluation will extrapolate beyond the calibration range

        Args:
            calib_model (dict): calibration model with 'Tmin_fit' and 'Tmax_fit'
            T_fit_min (float): minimum temperature (K) in the evaluation set
            T_fit_max (float): maximum temperature (K) in the evaluation set

        Returns:
            dict: {'calib_Tmin', 'calib_Tmax', 'low_extrap_K', 'high_extrap_K'}
    """

    Tmin = float(calib_model["Tmin_fit"])
    Tmax = float(calib_model["Tmax_fit"])
    return {
        "calib_Tmin": Tmin,
        "calib_Tmax": Tmax,
        "low_extrap_K": max(0.0, Tmin - float(T_fit_min)),
        "high_extrap_K": max(0.0, float(T_fit_max) - Tmax),
    }


# ----------
# Rate laws
# ----------

def k_eyring(T, dH_J_mol, dS_J_molK):
    # k(T) = (k_B T / h) * exp(dS/R) * exp(-dH/(R T))
    """
    Eyring rate law

        Args:
            T (array[float]): temperature array (K)
            dH_J_mol (float): enthalpy of activation dH (J/mol)
            dS_J_molK (float): entropy of activation dS (J/mol.K)

        Returns:
            numpy.ndarray: rate constant k(T) in s^-1
    """
    T = np.asarray(T, dtype=float)
    return (sc.Boltzmann * T / sc.h) * np.exp(dS_J_molK / sc.R) * np.exp(-dH_J_mol / (sc.R * T))


def k_arrhenius(T, Ea_J_mol, lnA):
    # k(T) = A * exp(-Ea /(R T))
    """
    Arrhenius rate law

        Args:
            T (array[float]): temperature array (K)
            Ea_J_mol (float): activation energy E_a (J/mol)
            lnA (float): natural log of pre-exponential factor A

        Returns:
            numpy.ndarray: rate constant k(T) in s^-1
    """
    T = np.asarray(T, dtype=float)
    return np.exp(lnA) * np.exp(-Ea_J_mol / (sc.R * T))


# ----------
# Integrated rate
# ----------

def integrated_rate_trap(k_vals, t):
    """
    L(t) = integral( k(t) ) dt on the experimental grid; L[0]=0
    """

    t = np.asarray(t, dtype=float)
    k_vals = np.asarray(k_vals, dtype=float)
    
    if t.size != k_vals.size:
        raise ValueError("integrated_rate_trap: length mismatch between t and k_vals")
    if t.size == 0:
        return np.array([], dtype=float)

    return cumulative_trapezoid(k_vals, t, initial=0.0)


# ----------
# Forward models
# ----------

def make_epsE_evaluator(A_E_eval, pathlength_cm, concentration_uM):
    """
    Convert absorbance calibration A_E(T) to extinction coefficient eps_E(T)

        Args:
            A_E_eval (func): callable of temperature -> absorbance
            pathlength_cm (float): optical path length (cm)
            concentration_uM (float): total photoswitch concentration (uM)

        Returns:
            tuple[func, float, float]: (eps_E(T) evaluator returning M^-1 cm^-1, pathlength_cm, concentration_M).
    """

    if pathlength_cm is None or concentration_uM is None:
        raise ValueError("Pathlength (cm) and concentration (uM) are required for ε-space kinetics.")
    l_cm = float(pathlength_cm)
    c_M = float(concentration_uM) * 1e-6
    if l_cm <= 0 or c_M <= 0:
        raise ValueError("Non-positive pathlength or concentration.")
    def epsE_dec(T_array):
        A = A_E_eval(T_array)
        return A / (l_cm * c_M)
    return epsE_dec, l_cm, c_M


def make_forward_model_eps(A_E_eval, kin_model, pathlength_cm, concentration_uM):
    """
    Build the eps-space forward model that predicts absorbance vs time

        Args:
            A_E_eval (func): callable returning A_E(T) for any temperature array
            kin_model (str): kinetic model, 'eyring' or 'arrhenius'
            pathlength_cm (float): optical path length (cm)
            concentration_uM (float): total photoswitch concentration (uM)

        Returns:
            A_model (func): callable forward(theta, t, T) -> modeled absorbance array
    """

    epsE_eval, l_cm, c_M = make_epsE_evaluator(A_E_eval, pathlength_cm, concentration_uM)

    def A_model(theta, t, T):
        T = np.asarray(T, dtype=float)
        t = np.asarray(t, dtype=float)

        if kin_model == "eyring":
            dH, dS, fZ0, epsZ = theta
            k_vals = k_eyring(T, dH, dS)
        elif kin_model == "arrhenius":
            Ea, lnA, fZ0, epsZ = theta
            k_vals = k_arrhenius(T, Ea, lnA)
        else:
            raise ValueError(f"Unknown kinetic model: {kin_model}")

        Λ = integrated_rate_trap(k_vals, t)
        fZ = fZ0 * np.exp(-Λ)
        fE = 1.0 - fZ

        epsE = epsE_eval(T)                # M^-1 cm^-1
        A_mod = l_cm * c_M * (epsE * fE + epsZ * fZ)
        return A_mod

    return A_model


# ----------
# Objective (SSR)
# ----------

def make_ssr_objective(forward, t, T, A_obs, weighting="uniform"):
    """
    Construct a sum-of-squared-residuals objective over a dataset

        Args:
            forward: Forward model callable, typically from make_forward_model_eps
            t: time array (s)
            T: temperature array (K) aligned with t
            A_obs: Observed absorbance array
            weighting: Residual weighting strategy (currently only 'uniform')

        Returns:
            Callable: Objective function ssr(theta) -> float.
    """

    t = np.asarray(t, dtype=float)
    T = np.asarray(T, dtype=float)
    A_obs = np.asarray(A_obs, dtype=float)
    if weighting != "uniform":
        raise NotImplementedError("Only uniform weighting supported at present.")
    def ssr(theta):
        A_mod = forward(theta, t, T)
        if not np.all(np.isfinite(A_mod)):
            return 1e50
        r = A_mod - A_obs
        return float(np.dot(r, r))
    return ssr


# ----------
# Bounds (eps-space)
# ----------

def default_bounds(kin_model, A_obs, pathlength_cm, concentration_uM):
    """
    Provide reasonable default parameter bounds for the kinetic model.

    Args:
        kin_model (str): kinetic model, 'eyring' or 'arrhenius'
        A_obs: Observed absorbance series used to scale eps bounds
        pathlength_cm (float): optical path length (cm)
        concentration_uM (float): concentration (uM)

    Returns:
        Tuple[numpy.ndarray, numpy.ndarray]: (lower_bounds, upper_bounds)
    """

    A_min = float(np.min(A_obs))
    A_max = float(np.max(A_obs))
    rng = max(1e-6, A_max - A_min)
    l_cm = float(pathlength_cm)
    c_M = float(concentration_uM) * 1e-6
    # Ballpark ε scale from mid absorbance
    eps_mid = max(1e-6, (A_min + 0.5 * rng) / (l_cm * c_M))
    eps_hi = 50.0 * eps_mid  # generous headroom

    if kin_model == "eyring":
        lower = [4.0e4,  -200.0, 0.0, 0.0]    # dH, dS, fZ0, epsZ_dec
        upper = [2.0e5,   200.0, 1.0, eps_hi]
    elif kin_model == "arrhenius":
        lower = [4.0e4,   -20.0, 0.0, 0.0]    # Ea, lnA, fZ0, epsZ_dec
        upper = [2.0e5,    40.0, 1.0, eps_hi]
    else:
        raise ValueError(f"Unknown kinetic model: {kin_model}")
    return np.array(lower, float), np.array(upper, float)


def near_bounds_flags(theta, lower, upper, rel_tol=0.02, abs_tol=None):
    """
    Flag parameters that lie within a tolerance of their bounds.

        Args:
            theta: parameter vector
            lower: lower bounds
            upper: upper bounds
            rel_tol: relative tolerance as a fraction of span
            abs_tol: absolute tolerance (optional)

        Returns:
            list[dict]: entries with index, value, bounds, and which bound is near.
    """
    theta = np.asarray(theta, float)
    lower = np.asarray(lower, float)
    upper = np.asarray(upper, float)
    span = upper - lower
    flags = []
    for i, val in enumerate(theta):
        lo, hi, sp = lower[i], upper[i], span[i]
        thr = max(rel_tol * sp, abs_tol if abs_tol is not None else 0.0)
        if (val - lo) <= thr:
            flags.append({"index": i, "value": float(val), "lower": float(lo), "upper": float(hi), "near": "lower"})
        elif (hi - val) <= thr:
            flags.append({"index": i, "value": float(val), "lower": float(lo), "upper": float(hi), "near": "upper"})
    return flags


# ----------
# Derived metrics/utilities
# ----------

def compute_half_life(rate_fn_name, theta, T_ref):
    """
    Compute k(T_ref) and the corresponding half-life.

        Args:
            rate_fn_name (str): kinetic model, 'eyring' or 'arrhenius'.
            theta: parameter vector [dH, dS, fZ0, epsZ] or [Ea, lnA, fZ0, epsZ]
            T_ref (float): reference temperature (K)

        Returns:
            tuple[float, float]: (k_ref in s^-1, t_half in s).
    """

    if rate_fn_name == "eyring":
        dH, dS, _, _ = theta
        k_ref = k_eyring(T_ref, dH, dS)
    else:
        Ea, lnA, _, _ = theta
        k_ref = k_arrhenius(T_ref, Ea, lnA)
    t_half = np.log(2.0) / k_ref
    return float(k_ref), float(t_half)


def format_half_life(seconds):
    """
    Render a human-readable half-life string with adaptive units

        Args:
            seconds (float): half-life in seconds

        Returns:
            str: formatted string such as '3.2 min' or '1.0 h'
    """

    s = float(seconds)
    if s < 60:
        return (s, "s")
    m = s / 60.0
    if m < 60:
        return (m, "min")
    h = m / 60.0
    if h < 24:
        return (h, "h")
    d = h / 24.0
    return (d, "d")


def derive_extinction_decadic(A_E_eval, A_Z_star, pathlength_cm, concentration_uM, T_ref):
    # Here A_Z_star is defined as l*c*eps_Z
    """
    Compute decadic extinction coefficients at T_ref for E and Z isomers

        Args:
            A_E_eval: callable A_E(T)
            A_Z_star: absorbance of Z* at T_ref (i.e., l*c*eps_Z)
            pathlength_cm (float): path length (cm)
            concentration_uM (float): concentration (uM)
            T_ref (float): reference temperature (K)

        Returns:
            dict: Keys 'epsilon_E_Minv_cmInv_at_Tref' and 'epsilon_Z_Minv_cmInv'.
    """

    if pathlength_cm is None or concentration_uM is None:
        raise ValueError("Pathlength (cm) and concentration (uM) must be provided to compute extinction coefficients.")
    c_M = float(concentration_uM) * 1e-6
    l_cm = float(pathlength_cm)
    if c_M <= 0.0 or l_cm <= 0.0:
        raise ValueError("Non-positive pathlength or concentration provided for extinction coefficient calculation.")
    A_E_Tref = float(A_E_eval(T_ref))
    epsilon_E_dec = A_E_Tref / (c_M * l_cm)
    epsilon_Z_dec = float(A_Z_star) / (c_M * l_cm)
    return {
        "epsilon_E_Minv_cmInv_at_Tref": epsilon_E_dec,
        "epsilon_Z_Minv_cmInv": epsilon_Z_dec,
        "eps_Tref_K": float(T_ref),
    }


# ----------
# Orchestrator
# ----------

def fit_kinetics(
    df_up,
    df_hold_or_none,
    calib_model,
    kin_model="eyring",
    thalf_K=298.15,
    eps_report_T_K=298.15,
    weighting="uniform",
    use_hold=True,
    pathlength_cm=None,
    concentration_uM=None,
    conc_ref_T_K=298.15,
    # differential evolution settings:
    de_strategy="best1bin",
    de_maxiter=1000,
    de_popsize=20,
    de_tol=1e-6,
    de_seed=42,
    de_workers=1,
):
    # Validate & collect fit data
    """
    Fit kinetic parameters to the up-ramp (and optional hold) segments.

    Args:
        df_up (DataFrame): aligned up-ramp ['time_s','temp_K','abs_corr']
        df_hold_or_none (DataFrame): hold segment or None
        calib_model: calibration model dict used to evaluate A_E(T)
        kin_model (str): kinetic model, 'eyring' (default) or 'arrhenius'
        thalf_K (float): temperature (K) at which to report half-life
        eps_report_T_K (float): Temperature (K) at which to report eps values
        weighting (str): residual weighting strategy (currently only 'uniform')
        use_hold (bool): whether to include the hold segment during fitting
        pathlength_cm (float): optical path length (cm)
        concentration_uM (float): total photoswitch concentration (uM)
        conc_ref_T_K (float): reference temperature (K) for the provided concentration
        thin_to_max_N: if provided, thin long traces to at most this many points
        random_state (int): random seed for reproducibility of thinned selection
        bounds: optional parameter bounds (lower, upper); if None, default_bounds() is used
        de_maxiter (int): max iterations for differential evolution
        de_popsize (int): population size for differential evolution
        de_tol (float): tolerance for differential evolution convergence
        de_seed (int): random seed for the optimizer
        de_workers (int): Number of workers; 1 means serial

    Returns:
        dict: Fit results including parameters, bounds, SSR, half-life and eps summaries, diagnostics, and fitted series
    """
    validate_fit_segment(df_up, "kinetics/up")
    if use_hold and df_hold_or_none is not None and len(df_hold_or_none) > 0:
        validate_fit_segment(df_hold_or_none, "kinetics/hold")
    df_fit = concat_fit_segments(df_up, df_hold_or_none, use_hold)

    t_full = np.asarray(df_fit["time_s"], float)
    T_full = np.asarray(df_fit["temp_K"], float)
    A_full = np.asarray(df_fit["abs_corr"], float)

    # Calibration and eps_E(T)
    A_E_eval = make_AE_evaluator_from_calibration(calib_model)
    calib_diag = calibration_extrapolation_diag(calib_model, float(np.min(T_full)), float(np.max(T_full)))
    forward = make_forward_model_eps(A_E_eval, kin_model, pathlength_cm, concentration_uM)

    # Thin very long traces for the DE objective (speed), but evaluate final fit on full grid
    N = t_full.size
    THIN_N = 8000
    idx = np.linspace(0, N - 1, THIN_N, dtype=int) if N > THIN_N else np.arange(N, dtype=int)
    t = t_full[idx]; T = T_full[idx]; A_obs = A_full[idx]

    # Objective & bounds
    ssr = make_ssr_objective(forward, t, T, A_obs, weighting=weighting)
    lower, upper = default_bounds(kin_model, A_obs, pathlength_cm, concentration_uM)
    bounds = list(zip(lower, upper))

    # Global optimization (with local polish)
    result = differential_evolution(
        func=ssr,
        bounds=bounds,
        strategy=de_strategy,
        maxiter=de_maxiter,
        popsize=de_popsize,
        tol=de_tol,
        mutation=(0.5, 1.0),
        recombination=0.7,
        seed=de_seed,
        polish=True,
        updating="deferred",
        workers=de_workers,
        disp=False,
    )

    theta_best = result.x
    ssr_best = float(result.fun)

    # Evaluate model on the full grid for output/plots
    A_fit_full = forward(theta_best, t_full, T_full)
    residual_full = A_fit_full - A_full

    fit_df = pd.DataFrame({
        "time_s": t_full,
        "temp_K": T_full,
        "abs_corr": A_full,
        "abs_fit": A_fit_full,
        "residual": residual_full,
    })

    # Derived metrics
    k_ref, t_half_s = compute_half_life(kin_model, theta_best, float(thalf_K))
    t_half_value, t_half_unit = format_half_life(t_half_s)
    dG_ref = None
    if kin_model == "eyring":
        dH, dS, _, _ = theta_best
        dG_ref = float(dH - float(thalf_K) * dS)

    # Map ε_Z to A_Z_star for backwards-compat with your outputs
    # A_Z_star = l*c*eps_Z
    _, l_cm, c_M = make_epsE_evaluator(A_E_eval, pathlength_cm, concentration_uM)
    epsZ_dec = float(theta_best[-1])
    A_Z_star_backcompat = l_cm * c_M * epsZ_dec

    # Diagnostics & summaries
    near_flags = near_bounds_flags(theta_best, lower, upper, rel_tol=0.02, abs_tol=None)
    diagnostics = {
        "optimizer": {
            "success": bool(result.success),
            "message": str(result.message),
            "nfev": int(result.nfev),
            "nit": int(result.nit),
            "ssr": ssr_best,
        },
        "calibration_domain": calib_diag,
        "near_bounds_flags": near_flags,
        "weighting": weighting,
        "used_sections": "up+hold" if (use_hold and df_hold_or_none is not None and len(df_hold_or_none) > 0) else "up-only",
        "n_points": int(len(t_full)),
    }

    # Package params with original keys
    if kin_model == "eyring":
        params = {
            "dH_J_per_mol": float(theta_best[0]),
            "dS_J_per_molK": float(theta_best[1]),
            "fZ0": float(theta_best[2]),
            "A_Z_star": float(A_Z_star_backcompat),   # absorbance of pure Z at total conc
        }
    else:
        params = {
            "Ea_J_per_mol": float(theta_best[0]),
            "lnA": float(theta_best[1]),
            "fZ0": float(theta_best[2]),
            "A_Z_star": float(A_Z_star_backcompat),
        }

    derived = {
        "k_at_Tref_s_inv": k_ref,
        "t_half_s": t_half_s,
        "t_half_display": {"value": t_half_value, "unit": t_half_unit},
        "dG_ref_J_per_mol": dG_ref,
        "thalf_K": float(thalf_K),
    }

    ext_dec = derive_extinction_decadic(A_E_eval, A_Z_star_backcompat, pathlength_cm, concentration_uM, float(eps_report_T_K))

    results = {
        "model": {
            "type": kin_model,
            "theta": theta_best,
            "bounds": {"lower": lower, "upper": upper},
        },
        "params": params,
        "fit": fit_df,
        "derived": derived,
        "extinction_decadic": ext_dec,
        "diagnostics": diagnostics,
        "metadata": {
            "pathlength_cm": float(pathlength_cm) if pathlength_cm is not None else None,
            "concentration_uM": float(concentration_uM) if concentration_uM is not None else None,
            "conc_ref_T_K": float(conc_ref_T_K),
            "eps_report_T_K": float(eps_report_T_K),
        },
    }

    if near_flags:
        print("[warning] One or more fitted parameters are near their bounds:")
        for f in near_flags:
            print(f"  - param[{f['index']}] = {f['value']:.6g} near {f['near']} bound "
                  f"[{f['lower']:.6g}, {f['upper']:.6g}]")

    low_ext = diagnostics["calibration_domain"]["low_extrap_K"]
    high_ext = diagnostics["calibration_domain"]["high_extrap_K"]
    if low_ext > 0 or high_ext > 0:
        span = (low_ext if low_ext > 0 else 0.0) + (high_ext if high_ext > 0 else 0.0)
        note = "small" if span <= 5.0 else "large"
        print(f"[note] Calibration A_E(T)/eps_E(T) extrapolation used ({note}): "
              f"{low_ext:.2f} K below, {high_ext:.2f} K above.")

    return results
