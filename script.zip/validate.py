# validate.py

"""
Validation helpers for time/temperature/absorbance DataFrames.
"""

import numpy as np
import pandas as pd


def require_columns(df, required, label="dataframe"):
    """
    Ensure all required columns exist in df. Raise ValueError on first miss.
    
        Args:
            df (DataFrame): dataframe to check for required columns
            required (list[strings]): columns required
            label (str): used for ValueError output, default "dataframe"

        Returns:
            Raises ValueError with first missing column
    """
    
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"{label}: missing required columns {missing}; got {list(df.columns)}")


def validate_time_monotonic(df, time_col="time_s", label="dataframe", strict=True):
    """
    Ensure time in dataframe is monotonic.
        Args:
            df (DataFrame): dataframe to check for monotonic time
            time_col (str): column title to check, default "time_s"
            label (str): used for ValueError output, default "dataframe"
            strict: If False, not strictly increasing (duplicates allowed), default True
        
        Returns:
            Raises ValueError with location of the first offending index.
    """
    
    require_columns(df, [time_col], label)

    t = np.asarray(df[time_col], dtype=float)
    if t.size < 2:
        raise ValueError(f"{label}: requires at least two time points in '{time_col}'.")

    dt = np.diff(t)
    ok = (dt > 0) if strict else (dt >= 0)
    if not np.all(ok):
        bad = np.where(~ok)[0]
        i = int(bad[0])
        t_prev = t[i]
        t_curr = t[i + 1]
        rel = "strictly increasing" if strict else "non-decreasing"
        raise ValueError(
            f"{label}: '{time_col}' must be {rel}; "
            f"offending pair at indices {i},{i+1}: {t_prev} -> {t_curr}."
        )


def validate_numeric_series(arr_like, name, label="dataframe"):
    """
    Coerce to float ndarray and ensure all finite.

        Args:
            arr_like: data to coerce to float ndarray
            name (str): used for ValueError output
            label (str): used for ValueError output, default "dataframe"
    
        Returns:
            1D array[float]
    """

    arr = np.asarray(arr_like, dtype=float)
    if not np.isfinite(arr).all():
        raise ValueError(f"{label}: non-finite values found in '{name}'")
    return arr


def check_aligned_triplet(df, label="aligned_df"):
    """
    Validate aligned frames that should have: ["time_s", "temp_K", "abs"].
    Also enforces strictly increasing time.
    """
    require_columns(df, ["time_s", "temp_K", "abs"], label)
    validate_time_monotonic(df, "time_s", label, strict=True)


def check_time_temp(df, label="temp_df"):
    """
    Validate temperature streams: ["time_s", "temp_K"].
    Also enforces strictly increasing time.
    """
    require_columns(df, ["time_s", "temp_K"], label)
    validate_time_monotonic(df, "time_s", label, strict=True)


def check_time_abs(df, label="abs_df"):
    """
    Validate absorbance streams: ["time_s", "abs"].
    Also enforces strictly increasing time.
    """
    require_columns(df, ["time_s", "abs"], label)
    validate_time_monotonic(df, "time_s", label, strict=True)