# phases.py

"""
Detection and splitting of up/hold/down phases in temperature ramps.
"""

import numpy as np
import pandas as pd
# local imports
import validate


# ----------
# Baseline
# ----------

def select_up_ramp_segment(aligned_df, label="baseline_up_ramp"):
    """
    Select only the *up-ramp* portion:
    all rows up to (and including) the maximum temperature point.

        Args:
            aligned_df (DataFrame): ['time_s','temp_K','abs']
                (must already be aligned; time_s strictly increasing)
            label (str): for diagnostics

        Returns:
            df_up (DataFrame): up-ramp subset of aligned_df, reset_index
            diag (dict): {
                'label',
                'n_raw',
                'n_kept',
                'frac_kept',
                'i_max_temp'
            }
    """

    # Validate columns
    validate.check_aligned_triplet(aligned_df, label)

    T = np.asarray(aligned_df["temp_K"], dtype=float)

    # Tmax marks the up-ramp end
    i_max = int(np.argmax(T))

    keep = np.zeros_like(T, dtype=bool)
    keep[: i_max + 1] = True

    n_raw  = int(T.size)
    n_kept = int(np.sum(keep))

    df_up = aligned_df.loc[keep].reset_index(drop=True)

    diag = {
        "label": label,
        "n_raw": n_raw,
        "n_kept": n_kept,
        "frac_kept": (n_kept / n_raw) if n_raw else 0.0,
        "i_max_temp": i_max,
    }

    return df_up, diag




# ----------
# Sample
# ----------

def _rolling_mean_centered(y, window_pts=10):
    """
    Centered rolling mean with min_periods=1
    """
    return pd.Series(np.asarray(y, dtype=float)).rolling(
        window=window_pts, center=True, min_periods=1
    ).mean().to_numpy()


def _contiguous_run_around_index(mask, i_center):
    """
    Given a boolean mask and a center index, return (iL, iR) inclusive
    for the contiguous True-run that contains i_center. If mask[i_center]
    is False, returns (i_center, i_center).
    """
    n = mask.size
    iL = iR = int(i_center)
    if n == 0:
        return 0, -1
    if not mask[i_center]:
        return int(i_center), int(i_center)
    # expand left
    i = i_center
    while i - 1 >= 0 and mask[i - 1]:
        i -= 1
        iL = i
    # expand right
    i = i_center
    while i + 1 < n and mask[i + 1]:
        i += 1
        iR = i
    return int(iL), int(iR)


def detect_sample_phases(
    sample_corrected_df,
    smooth_window_pts=10,
    band_K=0.02,
    use_hold=True,
    **_ignored_kwargs
):
    """
    Detect up / hold / down phases using a temperature band around
    the smoothed peak temperature.

        Args:
            sample_corrected_df (DataFrame): ['time_s','temp_K','abs'] (time strictly increasing)
            smooth_window_pts (int): rolling mean window for smoothing T, default 10
            band_K (float): half-band around peak (K). Hold is |T_s - T_peak| <= band_K
            use_hold (bool): isothermal hold used at top of experimental temperature ramp, default True

        Returns:
            masks (array[bool]): (mask_up, mask_hold, mask_down)
            dfs (array(DataFrame)): (df_up, df_hold, df_down)
            diag (dict): diagnostics
    """

    label = "sample_corrected"
    
    # Validate columns
    validate.require_columns(sample_corrected_df, ["time_s", "temp_K", "abs"], label)

    t = np.asarray(sample_corrected_df["time_s"], dtype=float)
    T = np.asarray(sample_corrected_df["temp_K"], dtype=float)

    n = T.size
    if n == 0:
        empty = np.zeros(0, dtype=bool)
        return (empty, empty, empty), (sample_corrected_df.copy(),)*3, {
            "note": "empty input",
            "params": {
                "smooth_window_pts": int(smooth_window_pts),
                "band_K": float(band_K),
                "use_hold": bool(use_hold)
            },
        }

    # 1) Smooth T (for classifying phases only)
    T_s = _rolling_mean_centered(T, window_pts=smooth_window_pts)

    # 2) Peak and in-band detection
    i_peak = int(np.argmax(T_s))
    T_peak = float(T_s[i_peak])

    in_band = np.abs(T_s - T_peak) <= float(band_K)

    # 3) Hold is the contiguous run in-band that contains the peak
    i_hold_L, i_hold_R = _contiguous_run_around_index(in_band, i_peak)

    # 4) Build masks (up before hold, hold in-band run, down after)
    mask_hold = np.zeros(n, dtype=bool)
    mask_up   = np.zeros(n, dtype=bool)
    mask_down = np.zeros(n, dtype=bool)

    if use_hold and (i_hold_R >= i_hold_L):
        # use the detected hold block
        mask_hold[i_hold_L : i_hold_R + 1] = True
        if i_hold_L > 0:
            mask_up[:i_hold_L] = True
        if i_hold_R + 1 < n:
            mask_down[i_hold_R + 1 :] = True
    else:
        # no-hold mode: split at i_peak (hold empty)
        mask_up[: i_peak + 1] = True
        if i_peak + 1 < n:
            mask_down[i_peak + 1 :] = True
        # mask_hold stays all-False

    # 5) Slice dataframes (baseline corrected data)
    df_up   = sample_corrected_df.loc[mask_up].reset_index(drop=True)
    df_hold = sample_corrected_df.loc[mask_hold].reset_index(drop=True)
    df_down = sample_corrected_df.loc[mask_down].reset_index(drop=True)

    # 6) Diagnostics
    def _dur(mask):
        i = np.where(mask)[0]
        if i.size == 0:
            return 0.0
        return float(t[i[-1]] - t[i[0]])

    def _Trange(mask):
        i = np.where(mask)[0]
        if i.size == 0:
            return (np.nan, np.nan)
        return (float(np.min(T[i])), float(np.max(T[i])))

    diag = {
        "i_peak_smoothed": int(i_peak),
        "T_peak_smoothed_K": float(T_peak),
        "indices": {"hold_L": int(i_hold_L), "hold_R": int(i_hold_R)},
        "durations_s": {
            "up": _dur(mask_up),
            "hold": _dur(mask_hold),
            "down": _dur(mask_down),
        },
        "T_ranges_K": {
            "up": _Trange(mask_up),
            "hold": _Trange(mask_hold),
            "down": _Trange(mask_down),
        },
        "counts": {
            "up": int(mask_up.sum()),
            "hold": int(mask_hold.sum()),
            "down": int(mask_down.sum()),
        },
        "params": {
            "smooth_window_pts": int(smooth_window_pts),
            "band_K": float(band_K),
            "use_hold": bool(use_hold),
        },
    }

    return (mask_up, mask_hold, mask_down), (df_up, df_hold, df_down), diag


def split_sample_phases(sample_corrected_df, **kwargs):
    """
    Wrapper function
    Returns a dict with masks, dfs, and diagnostics.
    kwargs forwarded to detect_sample_phases (e.g., smooth_window_pts=10, band_K=0.02).
    """

    masks, dfs, diag = detect_sample_phases(sample_corrected_df, **kwargs)
    mask_up, mask_hold, mask_down = masks
    df_up, df_hold, df_down = dfs
    
    return {
        "masks": {"up": mask_up, "hold": mask_hold, "down": mask_down},
        "dfs": {"up": df_up, "hold": df_hold, "down": df_down},
        "diag": diag,
    }