"""
Local-derivative Eyring points using the explicit (S - K) / L formula.

dA/dt =  (dA_E/dT * dT/dt) * (1 - f_Z)   -   (A_Z* - A_E) * k(T) * f_Z
=> k(T) = [ (dA_E/dT * dT/dt) * (1 - f_Z)  -  dA/dt ] / [ (A_Z* - A_E) * f_Z ]

All symbols are in absorbance space:
    A_E(T) = l * eps_E(T) * [PS]   (calibration polynomial)
    A_Z*   = l * eps_Z     * [PS]   (constant from global fit)

This module reuses data prep from kinetics.py to guarantee the same segments
are used as in the global fit.
"""

import numpy as np
import pandas as pd
# local imports
import validate as V
from kinetics import (
    make_AE_evaluator_from_calibration,
    concat_fit_segments,
    validate_fit_segment,
)

def _rolling_mean_centered(y, window_pts):
    if window_pts is None or window_pts < 3 or (window_pts % 2 == 0):
        return np.asarray(y, dtype=float)
    return (
        pd.Series(np.asarray(y, dtype=float))
        .rolling(window=int(window_pts), center=True, min_periods=1)
        .mean()
        .to_numpy()
    )

def _make_dAE_dT_evaluator(calib_model):
    # calib_model["coeffs_descending"] exists per calibration.fit_calibration_coeffs
    coeffs = np.asarray(calib_model["coeffs_descending"], dtype=float)
    dcoeffs = np.polyder(coeffs)  # derivative wrt T
    def dAE_dT(T_array):
        return np.polyval(dcoeffs, np.asarray(T_array, dtype=float))
    return dAE_dT

def eyring_points_from_segments(
    df_up,
    df_hold_or_none,
    calib_model,
    A_Z_star,
    use_hold=True,
    smooth_pts_A=11,          # centered MA window (odd int) for A(t)
    smooth_pts_T=11,          # centered MA window (odd int) for T(t)
    min_lever=1e-4,           # min |(A_Z* - A_E) * fZ| to keep a point
    clip_fZ=(0.02, 0.98),     # drop extremes where division explodes
    avg_pts=None,             # optional odd int rolling avg for ln(k/T) along 1/T
):
    """
    Build local Eyring points from the same up (±hold) data used in the global fit.

    Inputs
    ------
    df_up, df_hold_or_none : DataFrames containing columns ['time_s','temp_K','abs_corr']
    calib_model            : dict with polynomial for A_E(T); expects 'coeffs_descending'
    A_Z_star               : float, l*eps_Z*[PS] from global fit
    use_hold               : bool, whether to include the hold segment if present
    smooth_pts_A/T         : int, centered moving-average windows for A and T
    min_lever              : float, threshold for |(A_Z* - A_E) * fZ|
    clip_fZ                : (lo, hi) tuple, keep lo <= fZ <= hi
    avg_pts                : int or None, rolling mean window for ln(k/T) vs 1/T (visual only)

    Returns
    -------
    points_df : DataFrame with columns:
        ['time_s','temp_K','inv_T','k_local_s_inv','ln_k_over_T',
         'fZ','A_obs','A_E','dAE_dT','dTdt','dAdt','S_term','K_term','L_term','lever_abs']
    diag : dict of diagnostics
    """
    import numpy as np
    import pandas as pd
    import validate as V
    from kinetics import (
        make_AE_evaluator_from_calibration,
        concat_fit_segments,
        validate_fit_segment,
    )

    def _rolling_mean_centered(y, window_pts):
        if window_pts is None or window_pts < 3 or (window_pts % 2 == 0):
            return np.asarray(y, dtype=float)
        return (
            pd.Series(np.asarray(y, dtype=float))
            .rolling(window=int(window_pts), center=True, min_periods=1)
            .mean()
            .to_numpy()
        )

    def _make_dAE_dT_evaluator(calib_model):
        coeffs = np.asarray(calib_model["coeffs_descending"], dtype=float)
        dcoeffs = np.polyder(coeffs)  # derivative wrt T
        def dAE_dT(T_array):
            return np.polyval(dcoeffs, np.asarray(T_array, dtype=float))
        return dAE_dT

    # -------- validate & gather the exact same segments as the global fit --------
    validate_fit_segment(df_up, "eyring/up")
    if use_hold and df_hold_or_none is not None and len(df_hold_or_none) > 0:
        validate_fit_segment(df_hold_or_none, "eyring/hold")
    df = concat_fit_segments(df_up, df_hold_or_none, use_hold)

    t = np.asarray(df["time_s"], dtype=float)
    T_raw = np.asarray(df["temp_K"], dtype=float)
    A_raw = np.asarray(df["abs_corr"], dtype=float)
    V.validate_time_monotonic(df, time_col="time_s", label="eyring/segments", strict=True)
    V.validate_numeric_series(df["abs_corr"], "abs_corr", "eyring/segments")

    # -------- smoothing & derivatives wrt time (handles non-uniform dt) --------
    T_s = _rolling_mean_centered(T_raw, smooth_pts_T)
    A_s = _rolling_mean_centered(A_raw, smooth_pts_A)
    dTdt = np.gradient(T_s, t)
    dAdt = np.gradient(A_s, t)

    # -------- calibration evaluators on the SAME (smoothed) T --------
    A_E_eval = make_AE_evaluator_from_calibration(calib_model)
    dAE_dT_eval = _make_dAE_dT_evaluator(calib_model)
    A_E = np.asarray(A_E_eval(T_s), dtype=float)
    dAE_dT = np.asarray(dAE_dT_eval(T_s), dtype=float)

    # -------- fractions & terms for k(T) --------
    denom_A = (A_Z_star - A_E)
    with np.errstate(invalid="ignore", divide="ignore"):
        fZ = (A_s - A_E) / denom_A
    fZ = np.clip(fZ, 0.0, 1.0)

    S_term = dAE_dT * dTdt * (1.0 - fZ)   # spectral contribution
    L_term = denom_A * fZ                 # kinetic lever
    K_term = dAdt                         # observed absorbance rate

    with np.errstate(invalid="ignore", divide="ignore"):
        k_local = (S_term - K_term) / L_term

    lo, hi = clip_fZ
    keep = (
        np.isfinite(k_local) & np.isfinite(T_s) & np.isfinite(fZ)
        & (np.abs(L_term) >= float(min_lever))
        & (fZ >= float(lo)) & (fZ <= float(hi))
        & (k_local > 0.0)
    )

    pts = pd.DataFrame({
        "time_s": t,
        "temp_K": T_s,
        "inv_T": np.where(T_s > 0, 1.0 / T_s, np.nan),
        "k_local_s_inv": k_local,
        "A_obs": A_s,
        "A_E": A_E,
        "dAE_dT": dAE_dT,
        "dTdt": dTdt,
        "dAdt": dAdt,
        "S_term": S_term,
        "K_term": K_term,
        "L_term": L_term,
        "fZ": fZ,
        "lever_abs": np.abs(L_term),
    })
    pts = pts.loc[keep].copy()

    # Eyring coordinates
    pts["ln_k_over_T"] = np.log(pts["k_local_s_inv"] / pts["temp_K"])

    used_avg_pts = 1
    if avg_pts is not None and avg_pts >= 3 and (avg_pts % 2 == 1):
        pts.sort_values("inv_T", inplace=True, ignore_index=True)
        pts["ln_k_over_T"] = (
            pts["ln_k_over_T"]
            .rolling(window=int(avg_pts), center=True, min_periods=1)
            .mean()
        )
        used_avg_pts = int(avg_pts)

    diag = {
        "n_raw": int(len(df)),
        "n_points": int(len(pts)),
        "smooth_pts_A": int(smooth_pts_A) if smooth_pts_A else 1,
        "smooth_pts_T": int(smooth_pts_T) if smooth_pts_T else 1,
        "min_lever": float(min_lever),
        "clip_fZ": (float(lo), float(hi)),
        "used_sections": "up+hold" if (use_hold and df_hold_or_none is not None and len(df_hold_or_none) > 0) else "up-only",
        "avg_pts": used_avg_pts,
        "neg_k_dropped_pct": float(100.0 * np.mean(~np.isfinite(k_local) | (k_local <= 0.0))) if k_local.size else float("nan"),
    }

    cols = ["time_s","temp_K","inv_T","k_local_s_inv","ln_k_over_T",
            "fZ","A_obs","A_E","dAE_dT","dTdt","dAdt","S_term","K_term","L_term","lever_abs"]
    return pts[cols], diag

