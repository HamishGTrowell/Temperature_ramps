# filters.py

"""
Signal filtering utilities including a Hampel anomaly detector.
"""

import numpy as np
import pandas as pd


# ----------------------------
# Hampel filter (asymmetric edges via rolling with min_periods=1)
# ----------------------------

def hampel_mask(series, window=61, n_sigma=3.0):
    """
    Return a boolean mask (True = flagged anomaly) using a Hampel filter:
    - rolling median (centered), min_periods=1 at edges (asymmetric windows)
    - MAD estimated via median(|x - med|), scaled by 1.4826
    """
    if window % 2 == 0:
        window = window + 1  # ensure odd window

    s = series.astype(float)

    med = s.rolling(window=window, center=True, min_periods=1).median()
    abs_dev = (s - med).abs()
    mad = abs_dev.rolling(window=window, center=True, min_periods=1).median()

    s_np = s.to_numpy()
    med_np = med.to_numpy()
    mad_np = mad.to_numpy()

    sigma = 1.4826 * mad_np

    thr = n_sigma * sigma
    thr = np.where(np.isfinite(thr) & (thr > 0), thr, np.inf)

    mask = np.abs(s_np - med_np) > thr

    return mask


def apply_hampel_absorbance(df_abs, window=61, n_sigma=3.0, label="abs"):
    """
    Apply Hampel to absorbance column 'abs' of a dataframe with columns: ['time_s', 'abs'].
    Drops flagged rows and returns (filtered_df, stats_dict).
    """
    s = df_abs["abs"].astype(float)
    mask = hampel_mask(s, window=window, n_sigma=n_sigma)
    n_flag = int(mask.sum())
    n_total = int(len(df_abs))
    pct = 100.0 * n_flag / n_total if n_total else 0.0

    if mask.shape[0] != len(df_abs):
        raise RuntimeError("Hampel mask length mismatch with dataframe length.")
    filtered = df_abs.iloc[~mask].reset_index(drop=True)

    stats = {
        "stream": label,
        "filter": "hampel",
        "window": window,
        "n_sigma": n_sigma,
        "n_total": n_total,
        "n_flagged": n_flag,
        "pct_flagged": pct,
    }
    return filtered, stats


# ----------------------------
# Temperature jump test
# ----------------------------

def temperature_jump_mask(df_temp, max_K_per_min=20.0):
    # NOTE: A single anomalous value will also cause two datapoints to be removed.
    # Unlikely to be an issue given minimal anomalous values expected.
    """
    Flag a row i as anomaly if the rate |ΔT|/Δt between i-1 and i exceeds max_K_per_min.
    - df_temp expected columns: ['time_s', 'temp_K']
    - Returns boolean mask (True = anomaly) with same length as df_temp.
    - By convention, we flag the *later* point in the jump (index i).
    """
    t = df_temp["time_s"].to_numpy(dtype=float)
    T = df_temp["temp_K"].to_numpy(dtype=float)

    dt = np.diff(t)
    dT = np.diff(T)

    # Convert threshold to K/s
    thr_K_per_s = max_K_per_min / 60.0
    rate = np.abs(dT) / dt
    jump = rate > thr_K_per_s

    mask = np.zeros_like(T, dtype=bool)
    # Flag the later sample in each offending pair
    if len(mask) > 1:
        mask[1:] = np.where(np.isnan(rate), False, jump)

    return mask


def apply_jump_temp(df_temp, max_K_per_min=20.0, label="temp"):
    """
    Apply the temperature jump test and drop flagged rows.
    Returns (filtered_df, stats_dict).
    """
    mask = temperature_jump_mask(df_temp, max_K_per_min=max_K_per_min)
    n_flag = int(mask.sum())
    n_total = int(len(df_temp))
    pct = 100.0 * n_flag / n_total if n_total else 0.0

    filtered = df_temp.loc[~mask].reset_index(drop=True)

    stats = {
        "stream": label,
        "filter": "jump_test",
        "max_K_per_min": max_K_per_min,
        "n_total": n_total,
        "n_flagged": n_flag,
        "pct_flagged": pct,
    }
    return filtered, stats


# ----------------------------
# Sanity checks & reporting
# ----------------------------

def _report_drop_stats(stats_list):
    """
    Print overview of percentage dropped per data stream and warnings:
      - Absorbance: warn if >5%
      - Temperature: warn if >1%
    """
    print("\n--- Filtering summary ---")
    for st in stats_list:
        stream = st["stream"]
        pct = st["pct_flagged"]
        n_flag = st["n_flagged"]
        n_total = st["n_total"]
        print(f"{stream:>12}: dropped {n_flag}/{n_total} ({pct:.3f}%)")

    # Warnings
    for st in stats_list:
        stream = st["stream"]
        pct = st["pct_flagged"]
        if "abs" in stream.lower() and pct > 5.0:
            print(f"WARNING: >5% of absorbance data dropped in '{stream}' ({pct:.2f}%) due to anomalies.")
        if "temp" in stream.lower() and pct > 1.0:
            print(f"WARNING: >1% of temperature data dropped in '{stream}' ({pct:.2f}%) due to anomalies.")


def _warn_big_gaps(df, label):
    """
    After filtering, warn if any adjacent time gap is >10x median Δt.
    """
    if len(df) < 3:
        return
    dt = np.diff(df["time_s"].to_numpy(dtype=float))
    dt = dt[dt > 0]
    if len(dt) == 0:
        return
    med = np.median(dt)
    if med <= 0:
        return
    big = dt > (10.0 * med)
    if np.any(big):
        max_gap = dt.max()
        print(f"WARNING: Large time gap detected in '{label}'."
              f"Median Δt={med:.6g}s; max Δt={max_gap:.6g}s (>10× median).")


def _warn_absorbance_range(df_abs, label):
    """
    Warn if absorbance shows negative values below -0.05 or saturation above 2.
    """
    if "abs" not in df_abs.columns or len(df_abs) == 0:
        return
    a = df_abs["abs"].to_numpy(dtype=float)
    amin = np.nanmin(a)
    amax = np.nanmax(a)

    if amin < -0.05:
        print(f"WARNING: Negative absorbance values in '{label}' (min={amin:.4g}).")
    if amax > 2.0:
        print(f"WARNING: High absorbance values in '{label}' (max={amax:.4g}).")


def _warn_baseline_extrapolation(base_T_df, sample_T_df):
    """
    Compare sample temperature range to baseline range and warn about extrapolation.
    """
    if len(base_T_df) == 0 or len(sample_T_df) == 0:
        return

    base_min = float(np.nanmin(base_T_df["temp_K"]))
    base_max = float(np.nanmax(base_T_df["temp_K"]))
    samp_min = float(np.nanmin(sample_T_df["temp_K"]))
    samp_max = float(np.nanmax(sample_T_df["temp_K"]))

    low_extrap = max(0.0, base_min - samp_min) if samp_min < base_min else 0.0
    high_extrap = max(0.0, samp_max - base_max) if samp_max > base_max else 0.0

    if low_extrap > 0 or high_extrap > 0:
        total_extrap = max(low_extrap, high_extrap)
        msg = (f"NOTE: Temperature extrapolation required relative to baseline. "
               f"Low-end: {low_extrap:.3f} K; High-end: {high_extrap:.3f} K.")
        print(msg)
        if total_extrap > 5.0:
            print("SUGGESTION: Consider running a wider baseline; large extrapolation > 5 K.")
        else:
            print("INFO: Small extrapolation applied but likely OK (< 5 K).")


# ----------------------------
# Top-level orchestration
# ----------------------------

def filter_all_streams(base_T, base_A, samp_T, samp_A,
                       abs_window=61, abs_n_sigma=3.0, temp_jump_K_per_min=20.0,
                       verbose=True):
    """
    Apply:
      - Hampel (absorbance) with window=61, 3σ (drop flagged rows)
      - Jump test (temperature) at threshold 20 K/min (drop flagged rows)

    Then print:
      - % dropped with warnings (Abs>5%, Temp>1%)
      - Big-gap warnings (>5× median Δt)
      - Baseline extrapolation size & guidance
      - Absorbance range warnings (A<-0.05 or A>2)

    Returns filtered dataframes:
      base_T_f, base_A_f, samp_T_f, samp_A_f
    """
    stats = []

    # Absorbance: Hampel + drop
    base_A_f, stA_base = apply_hampel_absorbance(base_A, window=abs_window, n_sigma=abs_n_sigma, label="baseline_abs")
    stats.append(stA_base)

    samp_A_f, stA_samp = apply_hampel_absorbance(samp_A, window=abs_window, n_sigma=abs_n_sigma, label="sample_abs")
    stats.append(stA_samp)

    # Temperature: Jump test + drop
    base_T_f, stT_base = apply_jump_temp(base_T, max_K_per_min=temp_jump_K_per_min, label="baseline_temp")
    stats.append(stT_base)

    samp_T_f, stT_samp = apply_jump_temp(samp_T, max_K_per_min=temp_jump_K_per_min, label="sample_temp")
    stats.append(stT_samp)

    if verbose:
        _report_drop_stats(stats)

        # Big gaps after filtering
        _warn_big_gaps(base_A_f, "baseline_abs")
        _warn_big_gaps(samp_A_f, "sample_abs")
        _warn_big_gaps(base_T_f, "baseline_temp")
        _warn_big_gaps(samp_T_f, "sample_temp")

        # Absorbance ranges
        _warn_absorbance_range(base_A_f, "baseline_abs")
        _warn_absorbance_range(samp_A_f, "sample_abs")

        # Baseline extrapolation check (using filtered temperature streams)
        _warn_baseline_extrapolation(base_T_f, samp_T_f)

    return base_T_f, base_A_f, samp_T_f, samp_A_f


if __name__ == "__main__":
    import io_utils

    folder = "G:/projects/temp_ramp/program/example-data/"
    files = io_utils.discover_input_files(folder)
    base_T, base_A, samp_T, samp_A = io_utils.load_all_inputs(files)

    filter_all_streams(base_T, base_A, samp_T, samp_A, verbose=True)
