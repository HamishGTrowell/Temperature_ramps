# data.py

import argparse
import re
from pathlib import Path
import pandas as pd

# ------------------------- unit helpers -------------------------

_TIME_UNITS = {"s": 1.0, "sec": 1.0, "second": 1.0, "seconds": 1.0,
               "min": 60.0, "mins": 60.0, "minute": 60.0, "minutes": 60.0}
_TEMP_UNITS = {"K": ("K", lambda x: x),
               "C": ("K", lambda x: x + 273.15)}

def _to_seconds(series, unit):
    unit = str(unit).strip().lower()
    if unit not in _TIME_UNITS:
        raise ValueError("Unrecognised time unit '%s'. Use 's' or 'min'." % unit)
    return pd.to_numeric(series, errors="coerce") * _TIME_UNITS[unit]

def _temp_to_K(series, unit):
    if unit is None:
        unit = "C" if (pd.to_numeric(series, errors="coerce").dropna().median() < 200) else "K"
    unit = str(unit).strip().upper()
    if unit not in _TEMP_UNITS:
        raise ValueError("Unrecognised temp unit '%s'. Use 'C' or 'K'." % unit)
    _, fn = _TEMP_UNITS[unit]
    return pd.to_numeric(series, errors="coerce").map(fn)

# ------------------------- raw readers -------------------------

def read_combined_ramp_csv(path, label=""):
    df = pd.read_csv(path)
    probe_time_col = next((c for c in df.columns if re.search(r"probe.*time", c, re.I)), None)
    probe_temp_col = next((c for c in df.columns if re.search(r"probe.*temp", c, re.I)), None)
    abs_time_col = next((c for c in df.columns if re.search(r"abs.*time", c, re.I)), None)
    abs_col = next((c for c in df.columns if re.search(r"abs(?!.*time)", c, re.I)), None)
    if any(v is None for v in [probe_time_col, probe_temp_col, abs_time_col, abs_col]):
        raise ValueError("[%s] Could not identify required columns in '%s'." % (label, Path(path).name))
    temp_df = pd.DataFrame({
        "time_s": pd.to_numeric(df[probe_time_col], errors="coerce"),
        "temp_K": pd.to_numeric(df[probe_temp_col], errors="coerce"),
    }).dropna()
    abs_df = pd.DataFrame({
        "time_s": pd.to_numeric(df[abs_time_col], errors="coerce"),
        "abs": pd.to_numeric(df[abs_col], errors="coerce"),
    }).dropna()
    return temp_df, abs_df

def read_probe_txt_whitespace(path, time_unit="min", temp_unit="C", label=""):
    times = []
    temps = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = re.split(r"\s+", line)
            numeric = []
            for tok in parts:
                try:
                    numeric.append(float(tok))
                except ValueError:
                    pass
            if len(numeric) >= 2:
                times.append(numeric[0])
                temps.append(numeric[1])
    if not times:
        raise ValueError("[%s] No numeric rows found in '%s'." % (label, Path(path).name))
    temp_df = pd.DataFrame({"time_raw": times, "temp_raw": temps})
    temp_df["time_s"] = _to_seconds(temp_df["time_raw"], time_unit)
    temp_df["temp_K"] = _temp_to_K(temp_df["temp_raw"], temp_unit)
    return temp_df[["time_s", "temp_K"]]

def read_abs_two_row_header_csv(path, label=""):
    """
    Two-row header: row 0 is a label ('Sample 1'), row 1 are true headers like 'Time (min), Abs'.
    Strip any trailing metadata after the numeric table.
    """
    raw = pd.read_csv(path, header=None)
    if raw.shape[0] < 2:
        raise ValueError("[%s] Not enough rows in '%s' to parse two-row header." % (label, Path(path).name))

    header_row = raw.iloc[1].astype(str).str.strip().tolist()
    df = raw.iloc[2:].copy()
    df = df.iloc[:, :len(header_row)]
    df.columns = header_row[:df.shape[1]]

    time_col = next((c for c in df.columns if re.search(r"time", str(c), re.I)), None)
    abs_col  = next((c for c in df.columns if re.search(r"\babs\b",  str(c), re.I)), None)
    if time_col is None or abs_col is None:
        raise ValueError("[%s] Could not find 'time'/'abs' columns in '%s' (headers=%s)"
                         % (label, Path(path).name, header_row))

    time_unit = "min" if re.search(r"min", str(time_col), re.I) else "s"
    time_raw = pd.to_numeric(df[time_col], errors="coerce")
    abs_raw  = pd.to_numeric(df[abs_col], errors="coerce")

    m = (~time_raw.isna()) & (~abs_raw.isna())
    if not m.any():
        raise ValueError("[%s] No numeric time/abs rows found in '%s'." % (label, Path(path).name))

    # Keep the first contiguous numeric block (drop trailing metadata)
    idx = m.index.tolist()
    first_valid_pos = next((i for i, k in enumerate(idx) if m.iloc[i]), None)
    last_pos = first_valid_pos
    for i in range(first_valid_pos, len(idx)):
        if m.iloc[i]:
            last_pos = i
        else:
            break
    cleaned = df.iloc[first_valid_pos:last_pos+1]

    # Cut at first time decrease (extra safety)
    time_vals = pd.to_numeric(cleaned[time_col], errors="coerce")
    diffs = time_vals.diff()
    cut = len(cleaned)
    for i in range(1, len(cleaned)):
        if pd.notna(diffs.iloc[i]) and diffs.iloc[i] < 0:
            cut = i
            break
    cleaned = cleaned.iloc[:cut]

    abs_df = pd.DataFrame({
        "time_s": _to_seconds(pd.to_numeric(cleaned[time_col], errors="coerce"), time_unit),
        "abs":    pd.to_numeric(cleaned[abs_col], errors="coerce").astype(float),
    }).dropna()
    return abs_df

# ------------------------- writers -------------------------

def write_program_csvs(outdir,
                       base_temp=None,
                       base_abs=None,
                       samp_temp=None,
                       samp_abs=None,
                       force_SI_headers=True):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    def _w(df, fname, is_temp):
        if df is None:
            return
        if force_SI_headers:
            if is_temp:
                df2 = df.rename(columns={"time_s": "Time (s)", "temp_K": "Temp (K)"})[["Time (s)", "Temp (K)"]]
            else:
                df2 = df.rename(columns={"time_s": "Time (s)", "abs": "Abs (au)"}).loc[:, ["Time (s)", "Abs (au)"]]
        else:
            df2 = df.copy()
        df2.to_csv(outdir / fname, index=False)

    _w(base_temp, "baseline_temp.csv", True)
    _w(base_abs,  "baseline_abs.csv", False)
    _w(samp_temp, "sample_temp.csv", True)
    _w(samp_abs,  "sample_abs.csv", False)

# ------------------------- main pipeline -------------------------

def prepare_from_raw(sample_ramp_csv,
                     sample_probe_txt,
                     baseline_ramp_csv,
                     baseline_probe_txt,
                     outdir,
                     probe_time_unit="min",
                     probe_temp_unit="C",
                     force_SI_headers=True,
                     sample_abs_csv=None,
                     baseline_abs_csv=None):
    samp_temp = None
    samp_abs = None
    if sample_ramp_csv:
        t, a = read_combined_ramp_csv(sample_ramp_csv, label="sample")
        samp_temp, samp_abs = t, a
    if sample_abs_csv:
        samp_abs = read_abs_two_row_header_csv(sample_abs_csv, label="sample")
    if sample_probe_txt:
        t_probe = read_probe_txt_whitespace(sample_probe_txt, probe_time_unit, probe_temp_unit, label="sample")
        if samp_temp is None or len(samp_temp) == 0:
            samp_temp = t_probe

    base_temp = None
    base_abs = None
    if baseline_ramp_csv:
        t, a = read_combined_ramp_csv(baseline_ramp_csv, label="baseline")
        base_temp, base_abs = t, a
    if baseline_abs_csv:
        base_abs = read_abs_two_row_header_csv(baseline_abs_csv, label="baseline")
    if baseline_probe_txt:
        t_probe = read_probe_txt_whitespace(baseline_probe_txt, probe_time_unit, probe_temp_unit, label="baseline")
        if base_temp is None or len(base_temp) == 0:
            base_temp = t_probe

    write_program_csvs(outdir, base_temp, base_abs, samp_temp, samp_abs, force_SI_headers=force_SI_headers)

def build_arg_parser():
    p = argparse.ArgumentParser(
        prog="data.py",
        description="Convert raw UV-Vis outputs into program-friendly CSVs."
    )
    p.add_argument("--outdir", type=Path, default=Path("processed_data"),
                   help="Output directory for baseline_*.csv and sample_*.csv (default: processed_data/)")
    p.add_argument("--abs", type=str, default=None,
                   help="Base filename (without extension) for the SAMPLE absorbance CSV under raw_data/. "
                        "We will look for raw_data/<sample>.csv (two-row header format).")
    p.add_argument("--temp", type=str, default=None,
                   help="Base filename (without extension) for the PROBE temperature log under raw_data/. "
                        "We will look for raw_data/<probe>.txt (whitespace: time temp [clock date]).")

    p.add_argument("--sample-abs-csv", type=Path, default=None, help=argparse.SUPPRESS)
    p.add_argument("--sample-probe-txt", type=Path, default=None, help=argparse.SUPPRESS)
    p.add_argument("--baseline-abs-csv", type=Path, default=None, help=argparse.SUPPRESS)
    p.add_argument("--baseline-probe-txt", type=Path, default=None, help=argparse.SUPPRESS)

    p.add_argument("--probe-time-unit", choices=[
        "s", "sec", "second", "seconds", "min", "mins", "minute", "minutes"
    ], default="min", help="Units for the probe TXT time column (default: min).")
    p.add_argument("--probe-temp-unit", choices=["C", "K"], default="C",
                   help="Units for the probe TXT temperature column (default: C).")
    p.add_argument("--si-headers", dest="force_SI", action="store_true",
                   help="Write SI headers exactly as 'Time (s), Temp (K)' and 'Time (s), Abs (au)'. (default)")
    p.add_argument("--no-si-headers", dest="force_SI", action="store_false",
                   help="Keep dataframe column names (advanced).")
    p.set_defaults(force_SI=True)

    return p

def main(argv=None):
    args = build_arg_parser().parse_args(argv)

    sample_abs_csv = args.sample_abs_csv
    sample_probe_txt = args.sample_probe_txt
    if args.abs:
        base_dir = Path(__file__).resolve().parent
        sample_abs_csv = (base_dir / "raw_data" / (args.abs + ".csv"))
    if args.temp:
        base_dir = Path(__file__).resolve().parent
        sample_probe_txt = (base_dir / "raw_data" / (args.temp + ".txt"))

    if not (sample_abs_csv or sample_probe_txt):
        raise SystemExit("Provide --sample and/or --probe (looked up under raw_data/), "
                         "or use advanced flags (--sample-abs-csv / --sample-probe-txt). See --help.")

    prepare_from_raw(
        sample_ramp_csv=None,
        sample_probe_txt=sample_probe_txt,
        baseline_ramp_csv=None,
        baseline_probe_txt=args.baseline_probe_txt,
        outdir=args.outdir,
        probe_time_unit=args.probe_time_unit,
        probe_temp_unit=args.probe_temp_unit,
        force_SI_headers=args.force_SI,
        sample_abs_csv=sample_abs_csv,
        baseline_abs_csv=args.baseline_abs_csv,
    )
    print("Wrote reformatted CSVs to: %s" % (args.outdir,))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
